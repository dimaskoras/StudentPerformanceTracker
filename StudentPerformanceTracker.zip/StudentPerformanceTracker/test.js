const Provider = ({ value, children }) => <div>{children}</div>;
