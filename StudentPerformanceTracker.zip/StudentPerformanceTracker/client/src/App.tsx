import { Switch, Route } from "wouter";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider, RequireAuth, RequireRole } from "@/lib/auth";
import NotFound from "@/pages/not-found";
import LoginPage from "@/pages/login";
import Dashboard from "@/pages/dashboard";
import GradesPage from "@/pages/grades";
import CoursesPage from "@/pages/courses";
import NotificationsPage from "@/pages/notifications";
import AddGradesPage from "@/pages/add-grades";
import StudentsPage from "@/pages/students";
import TelegramBotPage from "@/pages/telegram-bot";
import AdminPage from "@/pages/admin";
import AdminCoursesPage from "@/pages/admin-courses";
import ProfilePage from "@/pages/profile";
import SettingsPage from "@/pages/settings";
import HelpPage from "@/pages/help";

// Основной компонент маршрутизации
function AppRoutes() {
  return (
    <Switch>
      <Route path="/login" component={LoginPage} />
      
      <Route path="/dashboard">
        <RequireAuth>
          <Dashboard />
        </RequireAuth>
      </Route>
      
      <Route path="/grades">
        <RequireAuth>
          <GradesPage />
        </RequireAuth>
      </Route>
      
      <Route path="/courses">
        <RequireAuth>
          <CoursesPage />
        </RequireAuth>
      </Route>
      
      <Route path="/notifications">
        <RequireAuth>
          <NotificationsPage />
        </RequireAuth>
      </Route>
      
      <Route path="/add-grades">
        <RequireAuth>
          <RequireRole roles={["teacher"]}>
            <AddGradesPage />
          </RequireRole>
        </RequireAuth>
      </Route>
      
      <Route path="/students">
        <RequireAuth>
          <RequireRole roles={["teacher"]}>
            <StudentsPage />
          </RequireRole>
        </RequireAuth>
      </Route>
      
      <Route path="/telegram-bot">
        <RequireAuth>
          <TelegramBotPage />
        </RequireAuth>
      </Route>
      
      {/* Новые маршруты для админки */}
      <Route path="/admin">
        <RequireAuth>
          <RequireRole roles={["teacher"]}>
            <AdminPage />
          </RequireRole>
        </RequireAuth>
      </Route>
      
      <Route path="/admin/courses">
        <RequireAuth>
          <RequireRole roles={["teacher"]}>
            <AdminCoursesPage />
          </RequireRole>
        </RequireAuth>
      </Route>
      
      {/* Профиль, настройки и справка */}
      <Route path="/profile">
        <RequireAuth>
          <ProfilePage />
        </RequireAuth>
      </Route>
      
      <Route path="/settings">
        <RequireAuth>
          <SettingsPage />
        </RequireAuth>
      </Route>
      
      <Route path="/help">
        <RequireAuth>
          <HelpPage />
        </RequireAuth>
      </Route>
      
      <Route path="/">
        <RequireAuth>
          <Dashboard />
        </RequireAuth>
      </Route>
      
      {/* Fallback to 404 */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <TooltipProvider>
      <Toaster />
      <AuthProvider>
        <AppRoutes />
      </AuthProvider>
    </TooltipProvider>
  );
}

export default App;
