import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { MainLayout } from "@/components/layout/main-layout";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { InsertUser, insertUserSchema } from "@shared/schema";
import { z } from "zod";
import { Helmet } from "react-helmet";
import { DataTable } from "@/components/ui/data-table";
import { ColumnDef } from "@tanstack/react-table";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

// Расширяем схему вставки пользователя для формы создания
const createUserSchema = insertUserSchema.extend({
  confirmPassword: z.string().min(1, "Подтвердите пароль"),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Пароли не совпадают",
  path: ["confirmPassword"],
});

type CreateUserFormValues = z.infer<typeof createUserSchema>;

export default function AdminPage() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [isAddingUser, setIsAddingUser] = useState(false);

  // Запрос на получение списка пользователей
  const { data: users = [], isLoading } = useQuery({
    queryKey: ["/api/users"],
    queryFn: async () => {
      const res = await fetch("/api/users");
      if (!res.ok) throw new Error("Не удалось загрузить пользователей");
      return res.json();
    }
  });

  // Мутация для создания нового пользователя
  const createUserMutation = useMutation({
    mutationFn: async (data: InsertUser) => {
      const response = await apiRequest("POST", "/api/users", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      setIsAddingUser(false);
      toast({
        title: "Пользователь создан",
        description: "Новый аккаунт успешно создан",
      });
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Ошибка",
        description: error instanceof Error ? error.message : "Не удалось создать пользователя",
      });
    }
  });

  const form = useForm<CreateUserFormValues>({
    resolver: zodResolver(createUserSchema),
    defaultValues: {
      username: "",
      password: "",
      confirmPassword: "",
      firstName: "",
      lastName: "",
      email: "",
      role: "student",
      group: "",
    },
  });

  function onSubmit(data: CreateUserFormValues) {
    // Удаляем confirmPassword перед отправкой на сервер
    const { confirmPassword, ...userData } = data;
    createUserMutation.mutate(userData);
  }

  // Мутация для удаления пользователя
  const deleteUserMutation = useMutation({
    mutationFn: async (userId: number) => {
      const response = await apiRequest("DELETE", `/api/users/${userId}`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      toast({
        title: "Пользователь удален",
        description: "Учетная запись успешно удалена",
      });
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Ошибка",
        description: error instanceof Error ? error.message : "Не удалось удалить пользователя",
      });
    }
  });

  // Мутация для обновления пользователя
  const updateUserMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number, data: Partial<InsertUser> }) => {
      const response = await apiRequest("PATCH", `/api/users/${id}`, data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users"] });
      toast({
        title: "Пользователь обновлен",
        description: "Данные пользователя успешно обновлены",
      });
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Ошибка",
        description: error instanceof Error ? error.message : "Не удалось обновить пользователя",
      });
    }
  });

  // Функция для просмотра оценок студента
  const navigateToStudentGrades = (studentId: number) => {
    window.location.href = `/grades?studentId=${studentId}`;
  };

  // Определение колонок для таблицы пользователей
  const columns: ColumnDef<any>[] = [
    {
      accessorKey: "id",
      header: "ID",
    },
    {
      accessorKey: "username",
      header: "Логин",
    },
    {
      accessorKey: "firstName",
      header: "Имя",
    },
    {
      accessorKey: "lastName",
      header: "Фамилия",
    },
    {
      accessorKey: "email",
      header: "Email",
    },
    {
      accessorKey: "role",
      header: "Роль",
      cell: ({ row }) => (
        <div className="capitalize">{row.getValue("role") === "teacher" ? "Преподаватель" : "Студент"}</div>
      ),
    },
    {
      accessorKey: "group",
      header: "Группа",
      cell: ({ row }) => row.getValue("group") || "—",
    },
    {
      id: "actions",
      header: "Действия",
      cell: ({ row }) => {
        const user = row.original;
        const userId = user.id;
        
        return (
          <div className="flex space-x-2">
            {user.role === "student" && (
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => navigateToStudentGrades(userId)}
              >
                Оценки
              </Button>
            )}
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => {
                // Здесь будет открытие модального окна для редактирования
                // TODO: Реализовать редактирование пользователя
                toast({
                  title: "Редактирование",
                  description: `Функция редактирования данных пользователя ${user.username} в разработке`,
                });
              }}
            >
              Изменить
            </Button>
            <Button 
              variant="destructive" 
              size="sm"
              onClick={() => {
                if (window.confirm(`Вы уверены, что хотите удалить пользователя ${user.username}?`)) {
                  deleteUserMutation.mutate(userId);
                }
              }}
            >
              Удалить
            </Button>
          </div>
        );
      },
    }
  ];

  return (
    <MainLayout>
      <Helmet>
        <title>Администрирование | Учет успеваемости студентов</title>
        <meta name="description" content="Панель администратора для управления пользователями системы" />
      </Helmet>

      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">Администрирование</h1>
        <Button 
          onClick={() => setIsAddingUser(!isAddingUser)}
          variant={isAddingUser ? "outline" : "default"}
        >
          {isAddingUser ? "Отмена" : "Добавить пользователя"}
        </Button>
      </div>

      {isAddingUser && (
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Создание нового пользователя</CardTitle>
            <CardDescription>Заполните форму для создания новой учетной записи</CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="username"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Логин</FormLabel>
                        <FormControl>
                          <Input placeholder="student2" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Email</FormLabel>
                        <FormControl>
                          <Input placeholder="student@example.com" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="firstName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Имя</FormLabel>
                        <FormControl>
                          <Input placeholder="Иван" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="lastName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Фамилия</FormLabel>
                        <FormControl>
                          <Input placeholder="Иванов" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="password"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Пароль</FormLabel>
                        <FormControl>
                          <Input type="password" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="confirmPassword"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Подтверждение пароля</FormLabel>
                        <FormControl>
                          <Input type="password" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="role"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Роль</FormLabel>
                        <Select
                          onValueChange={field.onChange}
                          defaultValue={field.value}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Выберите роль" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="student">Студент</SelectItem>
                            <SelectItem value="teacher">Преподаватель</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="group"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Группа</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="ИС-31" 
                            onChange={field.onChange}
                            onBlur={field.onBlur}
                            ref={field.ref}
                            name={field.name}
                            value={field.value || ''}
                          />
                        </FormControl>
                        <FormDescription>
                          Только для студентов
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                <div className="flex justify-end">
                  <Button 
                    type="submit" 
                    disabled={createUserMutation.isPending}
                  >
                    {createUserMutation.isPending ? "Создание..." : "Создать пользователя"}
                  </Button>
                </div>
              </form>
            </Form>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle>Список пользователей</CardTitle>
          <CardDescription>Управление учетными записями пользователей системы</CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="py-8 text-center">Загрузка пользователей...</div>
          ) : (
            <DataTable columns={columns} data={users} />
          )}
        </CardContent>
      </Card>
    </MainLayout>
  );
}