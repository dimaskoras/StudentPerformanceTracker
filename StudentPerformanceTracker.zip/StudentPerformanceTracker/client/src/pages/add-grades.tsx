import { MainLayout } from "@/components/layout/main-layout";
import { AddGradeForm } from "@/components/grades/add-grade-form";
import { useAuth } from "@/lib/auth";
import { useQuery } from "@tanstack/react-query";
import { Helmet } from "react-helmet";
import { Grade } from "@shared/schema";

interface GradeWithDetails extends Grade {
  courseName: string;
}

export default function AddGradesPage() {
  const { user } = useAuth();

  // Fetch recent grades added by the teacher
  const { data: recentGrades = [], isLoading } = useQuery<GradeWithDetails[]>({
    queryKey: ["/api/grades/teacher/recent"],
    enabled: !!user && user.role === "teacher",
    queryFn: async ({ queryKey }) => {
      // Since we don't have a specific endpoint for teacher's recent grades,
      // we'll use a placeholder implementation that would return an empty array
      // In a real system, this would fetch the teacher's recently added grades
      return [];
    },
  });

  return (
    <MainLayout>
      <Helmet>
        <title>Добавление оценок | Система учета успеваемости студентов</title>
        <meta name="description" content="Добавление новых оценок студентам в системе учета успеваемости студентов" />
      </Helmet>
      
      <header className="mb-8">
        <h1 className="text-2xl font-bold text-neutral-800 font-heading">Добавление оценок</h1>
        <p className="text-neutral-600 mt-1">
          Добавление новых оценок и комментариев для студентов
        </p>
      </header>

      <AddGradeForm />

      <div className="bg-white rounded-lg shadow p-6">
        <h2 className="text-lg font-semibold font-heading mb-4">Как это работает</h2>
        <div className="space-y-4">
          <div className="flex items-start">
            <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary text-white flex items-center justify-center mr-3">
              <span className="text-sm">1</span>
            </div>
            <div>
              <h3 className="font-medium">Выберите студента</h3>
              <p className="text-sm text-neutral-600 mt-1">
                Выберите студента из списка, которому хотите выставить оценку
              </p>
            </div>
          </div>
          <div className="flex items-start">
            <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary text-white flex items-center justify-center mr-3">
              <span className="text-sm">2</span>
            </div>
            <div>
              <h3 className="font-medium">Укажите дисциплину и тип работы</h3>
              <p className="text-sm text-neutral-600 mt-1">
                Выберите дисциплину и укажите за какой тип работы выставляется оценка
              </p>
            </div>
          </div>
          <div className="flex items-start">
            <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary text-white flex items-center justify-center mr-3">
              <span className="text-sm">3</span>
            </div>
            <div>
              <h3 className="font-medium">Добавьте комментарий</h3>
              <p className="text-sm text-neutral-600 mt-1">
                Добавьте развернутый комментарий к оценке для студента
              </p>
            </div>
          </div>
          <div className="flex items-start">
            <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary text-white flex items-center justify-center mr-3">
              <span className="text-sm">4</span>
            </div>
            <div>
              <h3 className="font-medium">Отправка уведомлений</h3>
              <p className="text-sm text-neutral-600 mt-1">
                После сохранения оценки, система автоматически отправит уведомление студенту на сайте и в Telegram (если подключен)
              </p>
            </div>
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
