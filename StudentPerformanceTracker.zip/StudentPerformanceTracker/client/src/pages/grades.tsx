import { useState } from "react";
import { MainLayout } from "@/components/layout/main-layout";
import { useAuth } from "@/lib/auth";
import { useQuery } from "@tanstack/react-query";
import { Grade, Course } from "@shared/schema";
import { Helmet } from "react-helmet";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { NotificationModal } from "@/components/modals/notification-modal";

interface GradeWithCourse extends Grade {
  courseName: string;
}

export default function GradesPage() {
  const { user } = useAuth();
  const [selectedCourse, setSelectedCourse] = useState<string>("all");
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedGrade, setSelectedGrade] = useState<GradeWithCourse | null>(null);
  const [modalOpen, setModalOpen] = useState(false);

  // Fetch grades
  const { data: grades = [], isLoading: isLoadingGrades } = useQuery<GradeWithCourse[]>({
    queryKey: [`/api/grades/student/${user?.id}`],
    enabled: !!user,
  });

  // Fetch courses
  const { data: courses = [], isLoading: isLoadingCourses } = useQuery<Course[]>({
    queryKey: ["/api/courses"],
    enabled: !!user,
  });

  const handleGradeClick = (grade: GradeWithCourse) => {
    setSelectedGrade(grade);
    setModalOpen(true);
  };

  // Filter grades based on selected course and search term
  const filteredGrades = grades.filter((grade) => {
    const matchesCourse = selectedCourse === "all" || grade.courseId.toString() === selectedCourse;
    const matchesSearch = 
      grade.courseName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      grade.workType.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (grade.comment && grade.comment.toLowerCase().includes(searchTerm.toLowerCase()));
    return matchesCourse && matchesSearch;
  });

  const getGradeColorClass = (value: number) => {
    switch (value) {
      case 5:
        return "bg-green-100 text-green-800";
      case 4:
        return "bg-yellow-100 text-yellow-800";
      case 3:
        return "bg-orange-100 text-orange-800";
      default:
        return "bg-red-100 text-red-800";
    }
  };

  const formatDate = (dateString: string | Date) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('ru-RU');
  };

  return (
    <MainLayout>
      <Helmet>
        <title>Успеваемость | Система учета успеваемости студентов</title>
        <meta name="description" content="Просмотр оценок и успеваемости в системе учета успеваемости студентов" />
      </Helmet>
      
      <header className="mb-8">
        <h1 className="text-2xl font-bold text-neutral-800 font-heading">Успеваемость</h1>
        <p className="text-neutral-600 mt-1">
          Просмотр всех оценок по дисциплинам
        </p>
      </header>

      <div className="bg-white rounded-lg shadow mb-8">
        <div className="p-6 border-b border-neutral-200">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <h2 className="text-lg font-semibold font-heading">Оценки</h2>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="w-full sm:w-64">
                <Select
                  value={selectedCourse}
                  onValueChange={setSelectedCourse}
                  disabled={isLoadingCourses}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Все дисциплины" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Все дисциплины</SelectItem>
                    {courses.map((course) => (
                      <SelectItem key={course.id} value={course.id.toString()}>
                        {course.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="w-full sm:w-64 relative">
                <Input
                  type="text"
                  placeholder="Поиск..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pr-10"
                />
                <span className="absolute right-3 top-2.5 text-neutral-400 material-icons">search</span>
              </div>
            </div>
          </div>
        </div>
        
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Дисциплина</TableHead>
                <TableHead>Тип работы</TableHead>
                <TableHead>Дата</TableHead>
                <TableHead>Оценка</TableHead>
                <TableHead>Комментарий</TableHead>
                <TableHead>Статус</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoadingGrades ? (
                [...Array(5)].map((_, index) => (
                  <TableRow key={index} className="animate-pulse">
                    <TableCell><Skeleton className="h-5 w-40" /></TableCell>
                    <TableCell><Skeleton className="h-5 w-32" /></TableCell>
                    <TableCell><Skeleton className="h-5 w-24" /></TableCell>
                    <TableCell><Skeleton className="h-6 w-6 rounded-full" /></TableCell>
                    <TableCell><Skeleton className="h-5 w-full max-w-xs" /></TableCell>
                    <TableCell><Skeleton className="h-5 w-16" /></TableCell>
                  </TableRow>
                ))
              ) : filteredGrades.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-8 text-neutral-500">
                    {searchTerm || selectedCourse !== "all" 
                      ? "Нет оценок, соответствующих фильтрам" 
                      : "У вас пока нет оценок"}
                  </TableCell>
                </TableRow>
              ) : (
                filteredGrades.map((grade) => (
                  <TableRow 
                    key={grade.id} 
                    className="hover:bg-neutral-50 cursor-pointer"
                    onClick={() => handleGradeClick(grade)}
                  >
                    <TableCell className="font-medium">{grade.courseName}</TableCell>
                    <TableCell>{grade.workType}</TableCell>
                    <TableCell>{formatDate(grade.date)}</TableCell>
                    <TableCell>
                      <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getGradeColorClass(grade.value)}`}>
                        {grade.value}
                      </span>
                    </TableCell>
                    <TableCell className="max-w-xs truncate">{grade.comment || "Нет комментария"}</TableCell>
                    <TableCell>
                      {!grade.isRead ? (
                        <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-blue-100 text-blue-800">
                          Новая
                        </span>
                      ) : (
                        <span className="text-neutral-500 text-sm">Прочитана</span>
                      )}
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </div>

      <NotificationModal
        notification={selectedGrade ? {
          id: 0,
          userId: user?.id || 0,
          title: "Просмотр оценки",
          message: `Оценка по предмету ${selectedGrade.courseName}`,
          type: "grade",
          isRead: true,
          date: selectedGrade.date,
          relatedId: selectedGrade.id
        } : null}
        grade={selectedGrade || undefined}
        open={modalOpen}
        onOpenChange={setModalOpen}
      />
    </MainLayout>
  );
}
