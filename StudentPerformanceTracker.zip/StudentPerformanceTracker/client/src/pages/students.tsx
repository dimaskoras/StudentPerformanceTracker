import { useState } from "react";
import { MainLayout } from "@/components/layout/main-layout";
import { useAuth } from "@/lib/auth";
import { useQuery } from "@tanstack/react-query";
import { Helmet } from "react-helmet";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Link } from "wouter";
import { UserWithStats } from "@shared/schema";

export default function StudentsPage() {
  const { user } = useAuth();
  const [searchTerm, setSearchTerm] = useState("");

  // Fetch students with stats
  const { data: students = [], isLoading } = useQuery<UserWithStats[]>({
    queryKey: ["/api/users/students/stats"],
    enabled: !!user && user.role === "teacher",
  });

  // Filter students based on search term
  const filteredStudents = students.filter(
    student => 
      student.firstName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      student.lastName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      student.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      student.group?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getGradeColor = (value: number) => {
    if (value >= 4.5) return "grade-excellent";
    if (value >= 4) return "grade-good";
    if (value >= 3) return "grade-satisfactory";
    return "grade-unsatisfactory";
  };

  return (
    <MainLayout>
      <Helmet>
        <title>Студенты | Система учета успеваемости студентов</title>
        <meta name="description" content="Список студентов и их статистика в системе учета успеваемости студентов" />
      </Helmet>
      
      <header className="mb-8">
        <h1 className="text-2xl font-bold text-neutral-800 font-heading">Список студентов</h1>
        <p className="text-neutral-600 mt-1">
          Управление студентами и просмотр их успеваемости
        </p>
      </header>

      <div className="bg-white rounded-lg shadow mb-8">
        <div className="p-6 border-b border-neutral-200">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <h2 className="text-lg font-semibold font-heading">Студенты</h2>
            <div className="w-full sm:w-64 relative">
              <Input
                type="text"
                placeholder="Поиск студента..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pr-10"
              />
              <span className="absolute right-3 top-2.5 text-neutral-400 material-icons">search</span>
            </div>
          </div>
        </div>
        
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>ФИО</TableHead>
                <TableHead>Группа</TableHead>
                <TableHead>Средний балл</TableHead>
                <TableHead>Пропуски</TableHead>
                <TableHead>Статус ТГ</TableHead>
                <TableHead className="text-right">Действия</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                [...Array(5)].map((_, index) => (
                  <TableRow key={index} className="animate-pulse">
                    <TableCell>
                      <div className="flex items-center">
                        <Skeleton className="h-8 w-8 rounded-full mr-4" />
                        <div>
                          <Skeleton className="h-4 w-32 mb-1" />
                          <Skeleton className="h-3 w-24" />
                        </div>
                      </div>
                    </TableCell>
                    <TableCell><Skeleton className="h-4 w-16" /></TableCell>
                    <TableCell><Skeleton className="h-4 w-10" /></TableCell>
                    <TableCell><Skeleton className="h-4 w-8" /></TableCell>
                    <TableCell><Skeleton className="h-5 w-20 rounded-full" /></TableCell>
                    <TableCell><Skeleton className="h-4 w-20 ml-auto" /></TableCell>
                  </TableRow>
                ))
              ) : filteredStudents.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-8 text-neutral-500">
                    {searchTerm 
                      ? "Нет студентов, соответствующих запросу" 
                      : "Список студентов пуст"}
                  </TableCell>
                </TableRow>
              ) : (
                filteredStudents.map((student) => (
                  <TableRow key={student.id} className="hover:bg-neutral-50">
                    <TableCell>
                      <div className="flex items-center">
                        <div className="flex-shrink-0 h-8 w-8 rounded-full bg-primary text-white flex items-center justify-center">
                          <span className="text-xs font-medium">{student.firstName.charAt(0)}{student.lastName.charAt(0)}</span>
                        </div>
                        <div className="ml-4">
                          <div className="text-sm font-medium text-neutral-800">{student.lastName} {student.firstName}</div>
                          <div className="text-xs text-neutral-500">{student.email}</div>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="text-sm text-neutral-600">{student.group || "—"}</div>
                    </TableCell>
                    <TableCell>
                      <div className={`text-sm font-medium ${getGradeColor(student.averageGrade || 0)}`}>
                        {student.averageGrade || "—"}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="text-sm text-neutral-600">{student.absencesCount || 0}</div>
                    </TableCell>
                    <TableCell>
                      {student.telegramConnected ? (
                        <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                          Подключен
                        </span>
                      ) : (
                        <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-neutral-100 text-neutral-800">
                          Не подключен
                        </span>
                      )}
                    </TableCell>
                    <TableCell className="text-right text-sm font-medium">
                      <Button 
                        variant="link" 
                        className="text-primary hover:text-primary-dark mr-3 p-0 h-auto"
                        onClick={() => window.location.href = `/grades?studentId=${student.id}`}
                      >
                        Оценки
                      </Button>
                      <Button 
                        variant="link" 
                        className="text-primary hover:text-primary-dark p-0 h-auto"
                        onClick={() => window.location.href = `/stats/student/${student.id}`}
                      >
                        Подробнее
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
        
        {filteredStudents.length > 0 && (
          <div className="px-6 py-4 bg-neutral-50 border-t border-neutral-200">
            <div className="flex items-center justify-between">
              <span className="text-sm text-neutral-700">Показано {filteredStudents.length} из {students.length} студентов</span>
            </div>
          </div>
        )}
      </div>
    </MainLayout>
  );
}
