import { MainLayout } from "@/components/layout/main-layout";
import { useAuth } from "@/lib/auth";
import { useQuery } from "@tanstack/react-query";
import { Course } from "@shared/schema";
import { Helmet } from "react-helmet";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import { useState } from "react";

export default function CoursesPage() {
  const { user } = useAuth();
  const [searchTerm, setSearchTerm] = useState("");

  // Fetch courses
  const { data: courses = [], isLoading } = useQuery<Course[]>({
    queryKey: ["/api/courses"],
    enabled: !!user,
  });

  // Fetch grades for student to determine completed courses
  const { data: grades = [] } = useQuery({
    queryKey: [`/api/grades/student/${user?.id}`],
    enabled: !!user && user.role === "student",
  });

  // Get completed courses (has at least one grade)
  const completedCourseIds = new Set(grades.map(grade => grade.courseId));

  // Filter courses based on search term
  const filteredCourses = courses.filter(
    course => course.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
             (course.description && course.description.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  // Split courses for tabs
  const activeCourses = filteredCourses;
  const completedCourses = filteredCourses.filter(course => completedCourseIds.has(course.id));
  const incompleteCourses = filteredCourses.filter(course => !completedCourseIds.has(course.id));

  const renderCourseGrid = (coursesToShow: Course[]) => (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-4">
      {isLoading ? (
        [...Array(6)].map((_, i) => (
          <Card key={i} className="animate-pulse">
            <CardHeader>
              <Skeleton className="h-6 w-3/4 mb-2" />
              <Skeleton className="h-4 w-1/2" />
            </CardHeader>
            <CardContent>
              <Skeleton className="h-20 w-full" />
            </CardContent>
          </Card>
        ))
      ) : coursesToShow.length === 0 ? (
        <div className="col-span-full text-center py-8 text-neutral-500">
          {searchTerm ? "Нет дисциплин, соответствующих поисковому запросу" : "Нет доступных дисциплин"}
        </div>
      ) : (
        coursesToShow.map(course => (
          <Card key={course.id} className="hover:shadow-md transition-shadow">
            <CardHeader>
              <CardTitle className="text-primary">{course.name}</CardTitle>
              <CardDescription>
                {user?.role === "student" && (
                  completedCourseIds.has(course.id) ? 
                    <span className="text-green-600 text-xs font-semibold">В процессе изучения</span> :
                    <span className="text-amber-600 text-xs font-semibold">Не начат</span>
                )}
                {user?.role === "teacher" && (
                  <span className="text-primary text-xs font-semibold">Преподаватель</span>
                )}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-neutral-600 text-sm">
                {course.description || "Описание отсутствует"}
              </p>
            </CardContent>
          </Card>
        ))
      )}
    </div>
  );

  return (
    <MainLayout>
      <Helmet>
        <title>Дисциплины | Система учета успеваемости студентов</title>
        <meta name="description" content="Список дисциплин и курсов в системе учета успеваемости студентов" />
      </Helmet>
      
      <header className="mb-8">
        <h1 className="text-2xl font-bold text-neutral-800 font-heading">Дисциплины</h1>
        <p className="text-neutral-600 mt-1">
          Просмотр доступных дисциплин и курсов
        </p>
      </header>

      <div className="bg-white rounded-lg shadow p-6 mb-8">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
          <h2 className="text-lg font-semibold font-heading">Поиск дисциплин</h2>
          <div className="w-full sm:w-64 relative">
            <Input
              type="text"
              placeholder="Поиск дисциплины..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pr-10"
            />
            <span className="absolute right-3 top-2.5 text-neutral-400 material-icons">search</span>
          </div>
        </div>

        {user?.role === "student" ? (
          <Tabs defaultValue="all" className="w-full">
            <TabsList className="grid grid-cols-3 mb-4">
              <TabsTrigger value="all">Все ({filteredCourses.length})</TabsTrigger>
              <TabsTrigger value="in-progress">В процессе ({completedCourses.length})</TabsTrigger>
              <TabsTrigger value="not-started">Не начатые ({incompleteCourses.length})</TabsTrigger>
            </TabsList>
            <TabsContent value="all">
              {renderCourseGrid(activeCourses)}
            </TabsContent>
            <TabsContent value="in-progress">
              {renderCourseGrid(completedCourses)}
            </TabsContent>
            <TabsContent value="not-started">
              {renderCourseGrid(incompleteCourses)}
            </TabsContent>
          </Tabs>
        ) : (
          renderCourseGrid(activeCourses)
        )}
      </div>
    </MainLayout>
  );
}
