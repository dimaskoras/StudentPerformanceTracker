import { MainLayout } from "@/components/layout/main-layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Helmet } from "react-helmet";

export default function HelpPage() {
  return (
    <MainLayout>
      <Helmet>
        <title>Справка | Учет успеваемости студентов</title>
        <meta name="description" content="Справочная информация и помощь по использованию системы" />
      </Helmet>
      
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">Справка</h1>
      </div>

      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Руководство пользователя</CardTitle>
          <CardDescription>
            Основная информация по использованию системы
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="item-1">
              <AccordionTrigger>Как работает система учета успеваемости?</AccordionTrigger>
              <AccordionContent>
                <p className="mb-2">
                  Система учета успеваемости позволяет студентам просматривать свои оценки по различным курсам, 
                  а преподавателям - выставлять оценки и управлять курсами.
                </p>
                <p>
                  После входа в систему вы увидите панель управления с основной информацией о вашей успеваемости 
                  или преподаваемых курсах, в зависимости от вашей роли.
                </p>
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="item-2">
              <AccordionTrigger>Как просматривать свои оценки?</AccordionTrigger>
              <AccordionContent>
                <p className="mb-2">
                  Для просмотра своих оценок перейдите в раздел "Успеваемость" в левом меню.
                </p>
                <p>
                  На этой странице вы увидите таблицу со всеми своими оценками, сгруппированными по курсам.
                  Вы можете нажать на любую оценку, чтобы увидеть дополнительную информацию, такую как комментарий преподавателя.
                </p>
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="item-3">
              <AccordionTrigger>Как выставлять оценки (для преподавателей)?</AccordionTrigger>
              <AccordionContent>
                <p className="mb-2">
                  Для выставления оценок перейдите в раздел "Выставить оценки" в левом меню.
                </p>
                <p>
                  На этой странице вы сможете выбрать курс, студента и выставить оценку с комментарием.
                  После сохранения студент получит уведомление о новой оценке.
                </p>
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="item-4">
              <AccordionTrigger>Как подключить Telegram для уведомлений?</AccordionTrigger>
              <AccordionContent>
                <p className="mb-2">
                  Для подключения Telegram-бота и получения уведомлений:
                </p>
                <ol className="list-decimal pl-6 space-y-1">
                  <li>Перейдите в раздел "Telegram-бот" в левом меню</li>
                  <li>Найдите @GradeNotifier_Bot в Telegram</li>
                  <li>Нажмите кнопку "Начать" или отправьте команду /start боту</li>
                  <li>Введите свой логин и пароль от системы в формате "логин:пароль"</li>
                  <li>После успешной авторизации вы начнете получать уведомления о новых оценках</li>
                </ol>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Часто задаваемые вопросы</CardTitle>
          <CardDescription>
            Ответы на наиболее распространенные вопросы
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="faq-1">
              <AccordionTrigger>Я забыл свой пароль. Что делать?</AccordionTrigger>
              <AccordionContent>
                Если вы забыли пароль, обратитесь к администратору системы или своему преподавателю для сброса пароля.
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="faq-2">
              <AccordionTrigger>Я не получаю уведомления в Telegram. Как это исправить?</AccordionTrigger>
              <AccordionContent>
                <p className="mb-2">Проверьте следующее:</p>
                <ul className="list-disc pl-6 space-y-1">
                  <li>Вы подключили правильного бота (@GradeNotifier_Bot)</li>
                  <li>Вы ввели правильный логин и пароль при авторизации</li>
                  <li>Вы не блокировали бота в Telegram</li>
                </ul>
                <p className="mt-2">
                  Если проблема не решена, попробуйте отключить и снова подключить бота, 
                  или обратитесь к администратору системы.
                </p>
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="faq-3">
              <AccordionTrigger>Как изменить свои личные данные?</AccordionTrigger>
              <AccordionContent>
                Для изменения личных данных (имя, фамилия, email) перейдите в раздел "Профиль" 
                в выпадающем меню в правом верхнем углу. Там вы сможете изменить свою личную информацию.
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="faq-4">
              <AccordionTrigger>Какие браузеры поддерживаются системой?</AccordionTrigger>
              <AccordionContent>
                <p className="mb-2">Система поддерживает все современные браузеры, включая:</p>
                <ul className="list-disc pl-6 space-y-1">
                  <li>Google Chrome</li>
                  <li>Mozilla Firefox</li>
                  <li>Microsoft Edge</li>
                  <li>Safari</li>
                </ul>
                <p className="mt-2">
                  Для лучшего опыта рекомендуется использовать последние версии браузеров.
                </p>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </CardContent>
      </Card>
    </MainLayout>
  );
}