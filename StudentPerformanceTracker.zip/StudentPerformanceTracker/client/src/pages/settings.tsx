import { useState } from "react";
import { MainLayout } from "@/components/layout/main-layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { Helmet } from "react-helmet";

export default function SettingsPage() {
  const { toast } = useToast();
  const [emailNotifications, setEmailNotifications] = useState(true);
  const [telegramNotifications, setTelegramNotifications] = useState(true);
  const [browserNotifications, setBrowserNotifications] = useState(false);
  const [darkMode, setDarkMode] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleToggleEmailNotifications = async () => {
    setIsLoading(true);
    try {
      // Здесь будет API запрос на сохранение настроек
      setEmailNotifications(!emailNotifications);
      toast({
        title: "Настройки сохранены",
        description: "Настройки email уведомлений обновлены",
      });
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Ошибка",
        description: "Не удалось сохранить настройки",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleToggleTelegramNotifications = async () => {
    setIsLoading(true);
    try {
      // Здесь будет API запрос на сохранение настроек
      setTelegramNotifications(!telegramNotifications);
      toast({
        title: "Настройки сохранены",
        description: "Настройки Telegram уведомлений обновлены",
      });
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Ошибка",
        description: "Не удалось сохранить настройки",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleToggleBrowserNotifications = async () => {
    setIsLoading(true);
    try {
      if (!browserNotifications) {
        // Запросить разрешение на уведомления
        const permission = await Notification.requestPermission();
        if (permission !== "granted") {
          throw new Error("Вы не дали разрешение на отправку уведомлений");
        }
      }
      
      // Здесь будет API запрос на сохранение настроек
      setBrowserNotifications(!browserNotifications);
      toast({
        title: "Настройки сохранены",
        description: "Настройки уведомлений в браузере обновлены",
      });
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Ошибка",
        description: error instanceof Error ? error.message : "Не удалось сохранить настройки",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleToggleDarkMode = async () => {
    setIsLoading(true);
    try {
      // Здесь будет логика изменения темы
      setDarkMode(!darkMode);
      toast({
        title: "Настройки сохранены",
        description: "Тема оформления изменена",
      });
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Ошибка",
        description: "Не удалось изменить тему",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <MainLayout>
      <Helmet>
        <title>Настройки | Учет успеваемости студентов</title>
        <meta name="description" content="Управление настройками системы и уведомлениями" />
      </Helmet>
      
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">Настройки</h1>
      </div>

      <Tabs defaultValue="notifications" className="space-y-4">
        <TabsList>
          <TabsTrigger value="notifications">Уведомления</TabsTrigger>
          <TabsTrigger value="interface">Интерфейс</TabsTrigger>
        </TabsList>
        
        <TabsContent value="notifications">
          <Card>
            <CardHeader>
              <CardTitle>Настройки уведомлений</CardTitle>
              <CardDescription>
                Настройте каналы получения уведомлений о новых оценках и событиях
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="email-notifications">Email уведомления</Label>
                    <p className="text-sm text-muted-foreground">
                      Получать уведомления о новых оценках на email
                    </p>
                  </div>
                  <Switch
                    id="email-notifications"
                    checked={emailNotifications}
                    onCheckedChange={handleToggleEmailNotifications}
                    disabled={isLoading}
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="telegram-notifications">Telegram уведомления</Label>
                    <p className="text-sm text-muted-foreground">
                      Получать уведомления о новых оценках в Telegram
                    </p>
                  </div>
                  <Switch
                    id="telegram-notifications"
                    checked={telegramNotifications}
                    onCheckedChange={handleToggleTelegramNotifications}
                    disabled={isLoading}
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="browser-notifications">Уведомления в браузере</Label>
                    <p className="text-sm text-muted-foreground">
                      Получать уведомления о новых оценках в браузере
                    </p>
                  </div>
                  <Switch
                    id="browser-notifications"
                    checked={browserNotifications}
                    onCheckedChange={handleToggleBrowserNotifications}
                    disabled={isLoading}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="interface">
          <Card>
            <CardHeader>
              <CardTitle>Настройки интерфейса</CardTitle>
              <CardDescription>
                Настройте внешний вид системы
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="dark-mode">Темная тема</Label>
                  <p className="text-sm text-muted-foreground">
                    Использовать темную тему оформления
                  </p>
                </div>
                <Switch
                  id="dark-mode"
                  checked={darkMode}
                  onCheckedChange={handleToggleDarkMode}
                  disabled={isLoading}
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </MainLayout>
  );
}