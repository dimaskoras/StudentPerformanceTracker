import { MainLayout } from "@/components/layout/main-layout";
import { StatCard } from "@/components/dashboard/stat-card";
import { RecentGrades } from "@/components/dashboard/recent-grades";
import { NotificationsCard } from "@/components/dashboard/notifications-card";
import { TelegramConnectCard } from "@/components/dashboard/telegram-connect-card";
import { useAuth } from "@/lib/auth";
import { useQuery } from "@tanstack/react-query";
import { Helmet } from "react-helmet";
import { Skeleton } from "@/components/ui/skeleton";

export default function Dashboard() {
  const { user } = useAuth();

  // Get student statistics
  const { data: stats, isLoading: isLoadingStats } = useQuery({
    queryKey: [`/api/stats/student/${user?.id}`],
    enabled: !!user && user.role === "student",
  });

  // Get teacher statistics (if applicable)
  const { data: teacherStats, isLoading: isLoadingTeacherStats } = useQuery({
    queryKey: ["/api/users/students/stats"],
    enabled: !!user && user.role === "teacher",
  });

  const isTeacher = user?.role === "teacher";

  const getGradeClass = (value: number) => {
    if (value >= 4.5) return "grade-excellent";
    if (value >= 4) return "grade-good";
    if (value >= 3) return "grade-satisfactory";
    return "grade-unsatisfactory";
  };

  const getStudentStats = () => {
    if (isLoadingStats) {
      return (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8 animate-pulse">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="bg-white rounded-lg shadow p-6">
              <div className="flex items-start justify-between">
                <div className="w-full">
                  <Skeleton className="h-4 w-24 mb-2" />
                  <Skeleton className="h-8 w-16" />
                </div>
                <Skeleton className="h-10 w-10 rounded-full" />
              </div>
              <Skeleton className="h-3 w-36 mt-4" />
            </div>
          ))}
        </div>
      );
    }

    if (!stats) return null;

    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <StatCard
          title="Средний балл"
          value={stats.averageGrade}
          icon="trending_up"
          iconBg="bg-green-100"
          iconColor="text-success"
          trend={{ value: "+0.3 по сравнению с прошлым семестром", isPositive: true }}
          valueClass={getGradeClass(stats.averageGrade)}
        />
        <StatCard
          title="Незакрытых дисциплин"
          value={stats.uncompletedCourses}
          icon="assignment_late"
          iconBg="bg-orange-100"
          iconColor="text-warning"
          footer="Из 8 текущих дисциплин"
        />
        <StatCard
          title="Новых оценок"
          value={stats.newGradesCount}
          icon="notifications_active"
          iconBg="bg-blue-100"
          iconColor="text-primary"
          footer="За последние 7 дней"
        />
        <StatCard
          title="Посещаемость"
          value={`${stats.attendancePercentage}%`}
          icon="event_available"
          iconBg="bg-green-100"
          iconColor="text-success"
          footer="В текущем семестре"
        />
      </div>
    );
  };

  const getTeacherStats = () => {
    if (isLoadingTeacherStats) {
      return (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8 animate-pulse">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="bg-white rounded-lg shadow p-6">
              <div className="flex items-start justify-between">
                <div className="w-full">
                  <Skeleton className="h-4 w-24 mb-2" />
                  <Skeleton className="h-8 w-16" />
                </div>
                <Skeleton className="h-10 w-10 rounded-full" />
              </div>
              <Skeleton className="h-3 w-36 mt-4" />
            </div>
          ))}
        </div>
      );
    }

    if (!teacherStats) return null;

    const studentCount = teacherStats.length;
    const checkedWorks = 24; // Mock data for now
    const pendingWorks = 12; // Mock data for now
    
    // Calculate average grade across all students
    const totalGrades = teacherStats.reduce((sum, student) => sum + (student.averageGrade || 0), 0);
    const averageGrade = studentCount ? (totalGrades / studentCount).toFixed(1) : "0.0";

    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <StatCard
          title="Всего студентов"
          value={studentCount}
          icon="people"
          iconBg="bg-blue-100"
          iconColor="text-primary"
          footer="По всем вашим курсам"
        />
        <StatCard
          title="Проверено работ"
          value={checkedWorks}
          icon="check_circle"
          iconBg="bg-green-100"
          iconColor="text-success"
          trend={{ value: "5 за последние 24 часа", isPositive: true }}
        />
        <StatCard
          title="Ожидают проверки"
          value={pendingWorks}
          icon="pending"
          iconBg="bg-orange-100"
          iconColor="text-warning"
          footer="По всем предметам"
        />
        <StatCard
          title="Средний балл группы"
          value={averageGrade}
          icon="analytics"
          iconBg="bg-blue-100"
          iconColor="text-primary"
          footer="По всем дисциплинам"
          valueClass={getGradeClass(Number(averageGrade))}
        />
      </div>
    );
  };

  return (
    <MainLayout>
      <Helmet>
        <title>Главная | Система учета успеваемости студентов</title>
        <meta name="description" content="Главная страница системы учета успеваемости студентов" />
      </Helmet>
      
      <header className="mb-8">
        <h1 className="text-2xl font-bold text-neutral-800 font-heading">
          Добро пожаловать, {user?.firstName}!
        </h1>
        <p className="text-neutral-600 mt-1">
          Просмотр последних обновлений по успеваемости
        </p>
      </header>

      {isTeacher ? (
        // Teacher Dashboard
        <section id="teacher-dashboard">
          {getTeacherStats()}
          <RecentGrades />
        </section>
      ) : (
        // Student Dashboard
        <section id="student-dashboard">
          {getStudentStats()}
          <RecentGrades />
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <NotificationsCard />
            <TelegramConnectCard />
          </div>
        </section>
      )}
    </MainLayout>
  );
}
