import { useState } from "react";
import { MainLayout } from "@/components/layout/main-layout";
import { useAuth } from "@/lib/auth";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Notification, Grade } from "@shared/schema";
import { Helmet } from "react-helmet";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { NotificationModal } from "@/components/modals/notification-modal";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";

interface GradeWithCourse extends Grade {
  courseName: string;
}

export default function NotificationsPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedNotification, setSelectedNotification] = useState<Notification | null>(null);
  const [selectedGrade, setSelectedGrade] = useState<GradeWithCourse | null>(null);
  const [modalOpen, setModalOpen] = useState(false);

  // Fetch all notifications
  const { data: notifications = [], isLoading } = useQuery<Notification[]>({
    queryKey: ["/api/notifications"],
    enabled: !!user,
  });

  // Fetch all grades for looking up related grades
  const { data: grades = [] } = useQuery<GradeWithCourse[]>({
    queryKey: [`/api/grades/student/${user?.id}`],
    enabled: !!user,
  });

  // Mutation to mark notification as read
  const markAsReadMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("PATCH", `/api/notifications/${id}/read`, { isRead: true });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/notifications"] });
      queryClient.invalidateQueries({ queryKey: ["/api/notifications/unread"] });
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Ошибка",
        description: error instanceof Error ? error.message : "Не удалось отметить уведомление как прочитанное",
      });
    },
  });

  // Mutation to mark all notifications as read
  const markAllAsReadMutation = useMutation({
    mutationFn: async () => {
      const unreadNotifications = notifications.filter(n => !n.isRead);
      await Promise.all(
        unreadNotifications.map(notification => 
          apiRequest("PATCH", `/api/notifications/${notification.id}/read`, { isRead: true })
        )
      );
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/notifications"] });
      queryClient.invalidateQueries({ queryKey: ["/api/notifications/unread"] });
      toast({
        title: "Успешно",
        description: "Все уведомления отмечены как прочитанные",
      });
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Ошибка",
        description: error instanceof Error ? error.message : "Не удалось отметить уведомления как прочитанные",
      });
    },
  });

  const handleNotificationClick = async (notification: Notification) => {
    // Find related grade if notification is about a grade
    let relatedGrade = null;
    if (notification.type === "grade" && notification.relatedId) {
      relatedGrade = grades.find(g => g.id === notification.relatedId) || null;
    }

    setSelectedNotification(notification);
    setSelectedGrade(relatedGrade);
    setModalOpen(true);

    // Mark as read if not already read
    if (!notification.isRead) {
      markAsReadMutation.mutate(notification.id);
    }
  };

  const handleMarkAllAsRead = () => {
    markAllAsReadMutation.mutate();
  };

  const unreadNotifications = notifications.filter(n => !n.isRead);
  const readNotifications = notifications.filter(n => n.isRead);

  const formatDate = (dateString: string | Date) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('ru-RU', {
      day: "numeric",
      month: "long",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit"
    });
  };

  const getNotificationBorder = (type: string) => {
    switch (type) {
      case "grade":
        return "border-primary";
      case "deadline":
        return "border-secondary";
      case "system":
        return "border-accent";
      default:
        return "border-neutral-300";
    }
  };

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case "grade":
        return "grade";
      case "deadline":
        return "event";
      case "system":
        return "send";
      default:
        return "info";
    }
  };

  const getNotificationIconColor = (type: string) => {
    switch (type) {
      case "grade":
        return "text-primary";
      case "deadline":
        return "text-secondary";
      case "system":
        return "text-accent";
      default:
        return "text-neutral-500";
    }
  };

  const renderNotificationList = (notificationsList: Notification[]) => (
    <div className="space-y-4">
      {isLoading ? (
        [...Array(3)].map((_, i) => (
          <div key={i} className="p-4 border-l-4 border-neutral-200 bg-white rounded-r-lg shadow animate-pulse">
            <div className="flex justify-between">
              <div className="w-full">
                <Skeleton className="h-5 w-1/3 mb-2" />
                <Skeleton className="h-4 w-full mb-3" />
                <Skeleton className="h-3 w-1/4" />
              </div>
              <Skeleton className="h-6 w-6 rounded-full ml-4" />
            </div>
          </div>
        ))
      ) : notificationsList.length === 0 ? (
        <div className="text-center py-8 text-neutral-500 bg-white rounded-lg shadow p-6">
          <span className="material-icons text-3xl mb-2">notifications_none</span>
          <p>У вас нет уведомлений в этой категории</p>
        </div>
      ) : (
        notificationsList.map(notification => (
          <div 
            key={notification.id}
            className={`p-4 border-l-4 ${getNotificationBorder(notification.type)} bg-white rounded-r-lg shadow hover:shadow-md transition-shadow cursor-pointer`}
            onClick={() => handleNotificationClick(notification)}
          >
            <div className="flex justify-between">
              <div>
                <h3 className="font-medium">{notification.title}</h3>
                <p className="text-sm text-neutral-700 mt-1">{notification.message}</p>
                <p className="text-xs text-neutral-500 mt-2">{formatDate(notification.date)}</p>
              </div>
              <span className={`material-icons ${getNotificationIconColor(notification.type)}`}>
                {getNotificationIcon(notification.type)}
              </span>
            </div>
          </div>
        ))
      )}
    </div>
  );

  return (
    <MainLayout>
      <Helmet>
        <title>Уведомления | Система учета успеваемости студентов</title>
        <meta name="description" content="Уведомления о новых оценках и событиях в системе учета успеваемости студентов" />
      </Helmet>
      
      <header className="mb-8">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-neutral-800 font-heading">Уведомления</h1>
            <p className="text-neutral-600 mt-1">
              Просмотр уведомлений о новых оценках и событиях
            </p>
          </div>
          {unreadNotifications.length > 0 && (
            <Button 
              variant="outline" 
              className="mt-4 sm:mt-0"
              onClick={handleMarkAllAsRead}
              disabled={markAllAsReadMutation.isPending}
            >
              <span className="material-icons mr-2 text-sm">done_all</span>
              {markAllAsReadMutation.isPending ? "Обработка..." : "Отметить все как прочитанные"}
            </Button>
          )}
        </div>
      </header>

      <Tabs defaultValue="unread" className="w-full">
        <TabsList className="grid grid-cols-2 mb-4">
          <TabsTrigger value="unread">
            Непрочитанные {unreadNotifications.length > 0 && `(${unreadNotifications.length})`}
          </TabsTrigger>
          <TabsTrigger value="all">
            Все {notifications.length > 0 && `(${notifications.length})`}
          </TabsTrigger>
        </TabsList>
        <TabsContent value="unread">
          {renderNotificationList(unreadNotifications)}
        </TabsContent>
        <TabsContent value="all">
          {renderNotificationList(notifications)}
        </TabsContent>
      </Tabs>

      <NotificationModal
        notification={selectedNotification}
        grade={selectedGrade || undefined}
        open={modalOpen}
        onOpenChange={setModalOpen}
      />
    </MainLayout>
  );
}
