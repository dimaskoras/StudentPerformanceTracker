import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { MainLayout } from "@/components/layout/main-layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { InsertCourse, insertCourseSchema } from "@shared/schema";
import { z } from "zod";
import { Helmet } from "react-helmet";
import { DataTable } from "@/components/ui/data-table";
import { ColumnDef } from "@tanstack/react-table";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { Trash2, Pencil } from "lucide-react";

export default function AdminCoursesPage() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [isAddingCourse, setIsAddingCourse] = useState(false);
  const [editingCourse, setEditingCourse] = useState<any | null>(null);
  const [deletingCourseId, setDeletingCourseId] = useState<number | null>(null);

  // Запрос на получение списка пользователей (преподавателей)
  const { data: teachers = [] } = useQuery({
    queryKey: ["/api/users/teachers"],
    queryFn: async () => {
      const res = await fetch("/api/users?role=teacher");
      if (!res.ok) throw new Error("Не удалось загрузить преподавателей");
      return res.json();
    }
  });

  // Запрос на получение списка курсов
  const { data: courses = [], isLoading } = useQuery({
    queryKey: ["/api/courses"],
    queryFn: async () => {
      const res = await fetch("/api/courses");
      if (!res.ok) throw new Error("Не удалось загрузить курсы");
      return res.json();
    }
  });

  // Мутация для создания нового курса
  const createCourseMutation = useMutation({
    mutationFn: async (data: InsertCourse) => {
      const response = await apiRequest("POST", "/api/courses", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/courses"] });
      setIsAddingCourse(false);
      form.reset();
      toast({
        title: "Курс создан",
        description: "Новый курс успешно добавлен",
      });
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Ошибка",
        description: error instanceof Error ? error.message : "Не удалось создать курс",
      });
    }
  });

  // Мутация для обновления курса
  const updateCourseMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number, data: InsertCourse }) => {
      const response = await apiRequest("PATCH", `/api/courses/${id}`, data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/courses"] });
      setEditingCourse(null);
      form.reset();
      toast({
        title: "Курс обновлен",
        description: "Курс успешно обновлен",
      });
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Ошибка",
        description: error instanceof Error ? error.message : "Не удалось обновить курс",
      });
    }
  });

  // Мутация для удаления курса
  const deleteCourseMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/courses/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/courses"] });
      setDeletingCourseId(null);
      toast({
        title: "Курс удален",
        description: "Курс успешно удален",
      });
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Ошибка",
        description: error instanceof Error ? error.message : "Не удалось удалить курс",
      });
    }
  });

  const form = useForm<z.infer<typeof insertCourseSchema>>({
    resolver: zodResolver(insertCourseSchema),
    defaultValues: {
      name: "",
      description: "",
      teacherId: 0,
    },
  });

  function onSubmit(data: z.infer<typeof insertCourseSchema>) {
    if (editingCourse) {
      updateCourseMutation.mutate({ id: editingCourse.id, data });
    } else {
      createCourseMutation.mutate(data);
    }
  }

  function handleEdit(course: any) {
    setEditingCourse(course);
    form.reset({
      name: course.name,
      description: course.description,
      teacherId: course.teacherId,
    });
  }

  function handleDelete(id: number) {
    setDeletingCourseId(id);
  }

  function confirmDelete() {
    if (deletingCourseId) {
      deleteCourseMutation.mutate(deletingCourseId);
    }
  }

  function cancelAddEdit() {
    setIsAddingCourse(false);
    setEditingCourse(null);
    form.reset();
  }

  // Определение колонок для таблицы курсов
  const columns: ColumnDef<any>[] = [
    {
      accessorKey: "id",
      header: "ID",
    },
    {
      accessorKey: "name",
      header: "Название",
    },
    {
      accessorKey: "description",
      header: "Описание",
    },
    {
      accessorKey: "teacherId",
      header: "Преподаватель",
      cell: ({ row }) => {
        const teacherId = row.getValue("teacherId");
        const teacher = teachers.find((t: any) => t.id === teacherId);
        return teacher ? `${teacher.firstName} ${teacher.lastName}` : "Не назначен";
      },
    },
    {
      id: "actions",
      header: "Действия",
      cell: ({ row }) => {
        const course = row.original;
        return (
          <div className="flex space-x-2">
            <Button variant="ghost" size="icon" onClick={() => handleEdit(course)}>
              <Pencil className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="icon" onClick={() => handleDelete(course.id)}>
              <Trash2 className="h-4 w-4 text-red-500" />
            </Button>
          </div>
        );
      },
    },
  ];

  return (
    <MainLayout>
      <Helmet>
        <title>Управление курсами | Учет успеваемости студентов</title>
        <meta name="description" content="Панель администратора для управления курсами в системе" />
      </Helmet>

      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">Управление курсами</h1>
        <Button 
          onClick={() => {
            setIsAddingCourse(!isAddingCourse);
            setEditingCourse(null);
            form.reset();
          }}
          variant={isAddingCourse || editingCourse ? "outline" : "default"}
        >
          {isAddingCourse || editingCourse ? "Отмена" : "Добавить курс"}
        </Button>
      </div>

      {(isAddingCourse || editingCourse) && (
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>{editingCourse ? "Редактирование курса" : "Создание нового курса"}</CardTitle>
            <CardDescription>
              {editingCourse 
                ? "Измените информацию о курсе" 
                : "Заполните форму для создания нового курса"}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Название курса</FormLabel>
                        <FormControl>
                          <Input placeholder="Математика" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="teacherId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Преподаватель</FormLabel>
                        <Select
                          onValueChange={(value) => field.onChange(Number(value))}
                          defaultValue={field.value.toString()}
                          value={field.value.toString()}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Выберите преподавателя" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {teachers.map((teacher: any) => (
                              <SelectItem key={teacher.id} value={teacher.id.toString()}>
                                {teacher.firstName} {teacher.lastName}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Описание</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="Описание курса" 
                          onChange={field.onChange}
                          onBlur={field.onBlur}
                          ref={field.ref}
                          name={field.name}
                          value={field.value || ''}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <div className="flex justify-end space-x-2">
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={cancelAddEdit}
                  >
                    Отмена
                  </Button>
                  <Button 
                    type="submit" 
                    disabled={createCourseMutation.isPending || updateCourseMutation.isPending}
                  >
                    {editingCourse ? "Сохранить" : "Создать"}
                  </Button>
                </div>
              </form>
            </Form>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle>Список курсов</CardTitle>
          <CardDescription>Управление курсами в системе</CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="py-8 text-center">Загрузка курсов...</div>
          ) : (
            <DataTable columns={columns} data={courses} searchColumn="name" searchPlaceholder="Поиск по названию..." />
          )}
        </CardContent>
      </Card>

      <AlertDialog open={deletingCourseId !== null} onOpenChange={(open) => !open && setDeletingCourseId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Вы уверены?</AlertDialogTitle>
            <AlertDialogDescription>
              Это действие нельзя отменить. Курс будет удален вместе со всеми связанными оценками.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Отмена</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete} className="bg-red-500 hover:bg-red-600">
              Удалить
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </MainLayout>
  );
}