import { useState } from "react";
import { MainLayout } from "@/components/layout/main-layout";
import { useAuth } from "@/lib/auth";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Helmet } from "react-helmet";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { TelegramConnectModal } from "@/components/modals/telegram-connect-modal";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";

export default function TelegramBotPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isConnectModalOpen, setIsConnectModalOpen] = useState(false);

  // Get current Telegram connection status
  const { data: telegramStatus, isLoading } = useQuery({
    queryKey: ["/api/telegram/status"],
    enabled: !!user,
  });

  // Mutation to disconnect Telegram
  const disconnectMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("POST", "/api/telegram/unlink");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/telegram/status"] });
      toast({
        title: "Telegram отключен",
        description: "Ваш аккаунт успешно отвязан от Telegram",
      });
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Ошибка",
        description: error instanceof Error ? error.message : "Не удалось отключить Telegram",
      });
    },
  });

  const handleDisconnect = () => {
    disconnectMutation.mutate();
  };

  const handleConnect = () => {
    setIsConnectModalOpen(true);
  };

  // Mock functions for settings updates (would be implemented with actual API)
  const handleToggleNotification = (type: string, enabled: boolean) => {
    toast({
      title: "Настройки обновлены",
      description: `Уведомления ${type} ${enabled ? 'включены' : 'отключены'}`,
    });
  };

  const handleUpdateSettings = () => {
    toast({
      title: "Настройки сохранены",
      description: "Ваши настройки уведомлений успешно сохранены",
    });
  };

  return (
    <MainLayout>
      <Helmet>
        <title>Telegram-бот | Система учета успеваемости студентов</title>
        <meta name="description" content="Привязка Telegram-бота для уведомлений в системе учета успеваемости студентов" />
      </Helmet>
      
      <header className="mb-8">
        <h1 className="text-2xl font-bold text-neutral-800 font-heading">Telegram-бот</h1>
        <p className="text-neutral-600 mt-1">
          Подключение уведомлений в Telegram
        </p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle>Telegram-бот для уведомлений</CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="animate-pulse">
                <div className="flex items-center mb-6">
                  <Skeleton className="w-12 h-12 rounded-full mr-4" />
                  <div>
                    <Skeleton className="h-5 w-40 mb-2" />
                    <Skeleton className="h-4 w-24" />
                  </div>
                </div>
                <Skeleton className="h-32 w-full mb-4" />
                <Skeleton className="h-10 w-1/3" />
              </div>
            ) : telegramStatus?.connected ? (
              <div>
                <div className="flex items-center mb-6">
                  <div className="w-12 h-12 rounded-full bg-accent bg-opacity-10 flex items-center justify-center mr-4">
                    <span className="material-icons text-accent">send</span>
                  </div>
                  <div>
                    <h3 className="font-medium text-neutral-800">Telegram подключен</h3>
                    <p className="text-sm text-neutral-600 mt-1">
                      @{telegramStatus.username || "пользователь"}
                    </p>
                  </div>
                </div>
                
                <div className="bg-white border border-neutral-200 rounded-lg p-4 mb-6">
                  <div className="flex justify-between items-center mb-4">
                    <h4 className="font-medium text-neutral-800">Настройки уведомлений</h4>
                  </div>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-neutral-700">Новые оценки</span>
                      <Switch 
                        defaultChecked 
                        id="new-grades" 
                        onCheckedChange={(checked) => handleToggleNotification("о новых оценках", checked)}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-neutral-700">Комментарии преподавателей</span>
                      <Switch 
                        defaultChecked 
                        id="comments" 
                        onCheckedChange={(checked) => handleToggleNotification("о комментариях", checked)}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-neutral-700">Предстоящие дедлайны</span>
                      <Switch 
                        defaultChecked 
                        id="deadlines" 
                        onCheckedChange={(checked) => handleToggleNotification("о дедлайнах", checked)}
                      />
                    </div>
                  </div>
                </div>
                
                <div className="flex space-x-4">
                  <Button 
                    variant="outline" 
                    onClick={handleDisconnect}
                    disabled={disconnectMutation.isPending}
                  >
                    {disconnectMutation.isPending ? "Отключение..." : "Отключить"}
                  </Button>
                  <Button onClick={handleUpdateSettings}>
                    Сохранить настройки
                  </Button>
                </div>
              </div>
            ) : (
              <div>
                <div className="flex items-center mb-4">
                  <div className="w-12 h-12 rounded-full bg-neutral-100 flex items-center justify-center mr-4">
                    <span className="material-icons text-neutral-400">send</span>
                  </div>
                  <div>
                    <h3 className="font-medium text-neutral-800">Получайте уведомления в Telegram</h3>
                    <p className="text-sm text-neutral-600 mt-1">Подключите бота для мгновенных уведомлений об оценках</p>
                  </div>
                </div>
                <div className="bg-neutral-50 rounded-lg p-4 mb-4">
                  <p className="text-sm text-neutral-700">1. Откройте <a href="https://t.me/GradeNotifierBot" target="_blank" rel="noopener noreferrer" className="text-primary">@GradeNotifierBot</a> в Telegram</p>
                  <p className="text-sm text-neutral-700 mt-2">2. Отправьте боту свой логин и пароль от системы</p>
                  <p className="text-sm text-neutral-700 mt-2">3. Дождитесь подтверждения привязки</p>
                </div>
                <Button onClick={handleConnect}>
                  Подключить Telegram
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Важная информация</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <h3 className="text-sm font-medium mb-1">Конфиденциальность</h3>
                <p className="text-sm text-neutral-600">
                  Ваши данные передаются через защищенное соединение. 
                  Мы не храним ваш пароль в Telegram.
                </p>
              </div>
              <div>
                <h3 className="text-sm font-medium mb-1">Команды бота</h3>
                <ul className="text-sm text-neutral-600 space-y-1">
                  <li><span className="font-mono">/start</span> - начать работу с ботом</li>
                  <li><span className="font-mono">/help</span> - получить справку</li>
                  <li><span className="font-mono">/status</span> - проверить статус</li>
                </ul>
              </div>
              <div>
                <h3 className="text-sm font-medium mb-1">Отключение уведомлений</h3>
                <p className="text-sm text-neutral-600">
                  Вы можете в любой момент отключить или настроить уведомления в этом разделе.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <TelegramConnectModal
        open={isConnectModalOpen}
        onOpenChange={setIsConnectModalOpen}
      />
    </MainLayout>
  );
}
