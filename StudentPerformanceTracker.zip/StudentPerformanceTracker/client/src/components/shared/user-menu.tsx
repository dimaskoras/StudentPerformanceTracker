import { useState, useRef, useEffect } from "react";
import { useAuth } from "@/lib/auth";
import { Link } from "wouter";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export function UserMenu() {
  const { user, logout } = useAuth();

  // Function to get initials from user's first and last name
  const getInitials = () => {
    if (!user) return "?";
    return `${user.firstName.charAt(0)}${user.lastName.charAt(0)}`;
  };

  // Full name for display
  const fullName = user ? `${user.firstName} ${user.lastName}` : "Загрузка...";

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button className="flex items-center space-x-2 focus:outline-none">
          <div className="w-8 h-8 rounded-full bg-primary text-white flex items-center justify-center">
            <span>{getInitials()}</span>
          </div>
          <span className="hidden md:block text-sm font-medium text-neutral-700">{fullName}</span>
          <span className="material-icons text-neutral-400">arrow_drop_down</span>
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-48">
        <DropdownMenuItem asChild>
          <Link href="/profile">
            <a className="w-full cursor-pointer">Профиль</a>
          </Link>
        </DropdownMenuItem>
        <DropdownMenuItem asChild>
          <Link href="/settings">
            <a className="w-full cursor-pointer">Настройки</a>
          </Link>
        </DropdownMenuItem>
        <DropdownMenuSeparator />
        <DropdownMenuItem 
          className="cursor-pointer"
          onClick={() => logout()}
        >
          Выйти
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
