import { ReactNode } from "react";
import { Link, useLocation } from "wouter";

interface SidebarLinkProps {
  href: string;
  icon: string;
  children: ReactNode;
  isActive?: boolean;
}

function SidebarLink({ href, icon, children, isActive }: SidebarLinkProps) {
  const classes = `sidebar-link flex items-center px-3 py-2 text-neutral-700 hover:bg-neutral-100 rounded-md ${
    isActive ? "active bg-primary bg-opacity-10 border-l-4 border-primary" : ""
  }`;

  return (
    <Link href={href}>
      <a className={classes}>
        <span className="material-icons mr-3 text-neutral-500">{icon}</span>
        <span>{children}</span>
      </a>
    </Link>
  );
}

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
  userRole: string;
}

export function Sidebar({ isOpen, onClose, userRole }: SidebarProps) {
  const [location] = useLocation();
  
  const isActive = (path: string) => location === path;
  
  return (
    <aside 
      className={`w-full lg:w-64 bg-white shadow-md lg:block ${
        isOpen ? "block" : "hidden"
      } transform transition-transform duration-300 h-screen lg:h-auto fixed lg:sticky top-0 lg:top-auto z-30 lg:z-0`}
    >
      <div className="p-4">
        <div className="flex items-center justify-between lg:justify-center pb-4 border-b border-neutral-200">
          <h2 className="font-heading font-semibold text-primary">МосГУ</h2>
          <button 
            onClick={onClose}
            className="lg:hidden text-neutral-500"
          >
            <span className="material-icons">close</span>
          </button>
        </div>
        
        <div className="mt-6 space-y-1">
          <p className="text-xs text-neutral-500 px-3 mb-2 uppercase">Меню</p>
          <SidebarLink href="/dashboard" icon="dashboard" isActive={isActive("/dashboard")}>
            Главная
          </SidebarLink>
          <SidebarLink href="/grades" icon="grade" isActive={isActive("/grades")}>
            Успеваемость
          </SidebarLink>
          <SidebarLink href="/courses" icon="book" isActive={isActive("/courses")}>
            Дисциплины
          </SidebarLink>
          <SidebarLink href="/notifications" icon="notifications" isActive={isActive("/notifications")}>
            Уведомления
          </SidebarLink>
        </div>
        
        {/* Teacher/Admin specific menu */}
        {userRole === "teacher" && (
          <div className="mt-6 space-y-1">
            <p className="text-xs text-neutral-500 px-3 mb-2 uppercase">Преподаватель</p>
            <SidebarLink href="/add-grades" icon="add_circle" isActive={isActive("/add-grades")}>
              Добавить оценки
            </SidebarLink>
            <SidebarLink href="/students" icon="people" isActive={isActive("/students")}>
              Студенты
            </SidebarLink>
            <SidebarLink href="/admin" icon="admin_panel_settings" isActive={isActive("/admin")}>
              Управление пользователями
            </SidebarLink>
            <SidebarLink href="/admin/courses" icon="edit_note" isActive={isActive("/admin/courses")}>
              Управление курсами
            </SidebarLink>
          </div>
        )}

        <div className="mt-6 space-y-1">
          <p className="text-xs text-neutral-500 px-3 mb-2 uppercase">Telegram</p>
          <SidebarLink href="/telegram-bot" icon="send" isActive={isActive("/telegram-bot")}>
            Привязать бота
          </SidebarLink>
        </div>

        <div className="mt-6 border-t border-neutral-200 pt-4">
          <SidebarLink href="/settings" icon="settings" isActive={isActive("/settings")}>
            Настройки
          </SidebarLink>
          <SidebarLink href="/help" icon="help" isActive={isActive("/help")}>
            Помощь
          </SidebarLink>
        </div>
      </div>
    </aside>
  );
}
