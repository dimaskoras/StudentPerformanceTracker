import { useState } from "react";
import { UserMenu } from "./user-menu";
import { useAuth } from "@/lib/auth";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Notification } from "@shared/schema";

interface HeaderProps {
  toggleSidebar: () => void;
}

export function Header({ toggleSidebar }: HeaderProps) {
  const { user } = useAuth();
  const [notificationsOpen, setNotificationsOpen] = useState(false);

  // Fetch unread notifications
  const { data: unreadNotifications = [] } = useQuery<Notification[]>({
    queryKey: ["/api/notifications/unread"],
    enabled: !!user,
  });

  const hasUnreadNotifications = unreadNotifications.length > 0;

  return (
    <header className="bg-white shadow-md">
      <div className="container mx-auto px-4 py-3 flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <button 
            onClick={toggleSidebar}
            className="lg:hidden text-neutral-600 focus:outline-none"
          >
            <span className="material-icons">menu</span>
          </button>
          <h1 className="text-xl font-bold text-primary font-heading">Успеваемость студентов</h1>
        </div>
        <div className="flex items-center space-x-4">
          <div className="relative">
            <button 
              className="p-2 rounded-full hover:bg-neutral-100 focus:outline-none"
              onClick={() => setNotificationsOpen(true)}
            >
              <span className="material-icons">notifications</span>
              {hasUnreadNotifications && (
                <span className="absolute top-1 right-1 w-2 h-2 bg-secondary rounded-full"></span>
              )}
            </button>
          </div>
          <UserMenu />
        </div>
      </div>

      <Dialog open={notificationsOpen} onOpenChange={setNotificationsOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Уведомления</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 max-h-[60vh] overflow-y-auto py-4">
            {unreadNotifications.length === 0 ? (
              <div className="text-center py-6 text-neutral-500">
                <span className="material-icons text-3xl mb-2">notifications_none</span>
                <p>У вас нет непрочитанных уведомлений</p>
              </div>
            ) : (
              unreadNotifications.map((notification) => (
                <div 
                  key={notification.id} 
                  className="p-3 border-l-4 border-primary bg-primary-light bg-opacity-5"
                >
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="text-sm font-medium">{notification.title}</p>
                      <p className="text-xs text-neutral-500 mt-1">
                        {new Date(notification.date).toLocaleString('ru-RU')}
                      </p>
                    </div>
                    <span className="material-icons text-primary text-sm">
                      {notification.type === 'grade' ? 'grade' : 
                        notification.type === 'deadline' ? 'event' : 'info'}
                    </span>
                  </div>
                  <p className="text-sm mt-2">{notification.message}</p>
                </div>
              ))
            )}
          </div>
          <div className="flex justify-between mt-4">
            <Link href="/notifications">
              <a className="text-primary text-sm hover:underline">
                Все уведомления
              </a>
            </Link>
          </div>
        </DialogContent>
      </Dialog>
    </header>
  );
}
