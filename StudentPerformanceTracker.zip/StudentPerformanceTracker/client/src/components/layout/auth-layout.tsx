import { ReactNode } from "react";

interface AuthLayoutProps {
  children: ReactNode;
  title?: string;
  subtitle?: string;
}

export function AuthLayout({
  children,
  title = "Система учёта успеваемости",
  subtitle = "Вход в личный кабинет",
}: AuthLayoutProps) {
  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-lg p-8 w-full max-w-md">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-primary font-heading">{title}</h1>
          <p className="text-neutral-600 mt-2">{subtitle}</p>
        </div>
        
        {children}
      </div>
    </div>
  );
}
