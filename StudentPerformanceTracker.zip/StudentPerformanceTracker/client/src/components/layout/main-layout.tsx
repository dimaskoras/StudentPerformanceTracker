import { ReactNode, useState, useEffect } from "react";
import { Sidebar } from "@/components/shared/sidebar";
import { Header } from "@/components/shared/header";
import { useAuth } from "@/lib/auth";
import { useMobile } from "@/hooks/use-mobile";

interface MainLayoutProps {
  children: ReactNode;
}

export function MainLayout({ children }: MainLayoutProps) {
  const { user } = useAuth();
  const isMobile = useMobile();
  const [sidebarOpen, setSidebarOpen] = useState(!isMobile);

  useEffect(() => {
    setSidebarOpen(!isMobile);
  }, [isMobile]);

  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };

  const closeSidebar = () => {
    if (isMobile) {
      setSidebarOpen(false);
    }
  };

  return (
    <div className="min-h-screen bg-neutral-100">
      <Header toggleSidebar={toggleSidebar} />
      <div className="container mx-auto px-4 flex flex-col lg:flex-row">
        <Sidebar 
          isOpen={sidebarOpen} 
          onClose={closeSidebar}
          userRole={user?.role || "student"}
        />
        <main className="flex-1 py-8">
          {children}
        </main>
      </div>
    </div>
  );
}
