import { ReactNode } from "react";

interface StatCardProps {
  title: string;
  value: string | number;
  icon: string;
  iconBg: string;
  iconColor: string;
  trend?: {
    value: string;
    isPositive: boolean;
  };
  footer?: string;
  valueClass?: string;
}

export function StatCard({
  title,
  value,
  icon,
  iconBg,
  iconColor,
  trend,
  footer,
  valueClass = "text-neutral-800"
}: StatCardProps) {
  return (
    <div className="bg-white rounded-lg shadow p-6">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-neutral-500 text-sm">{title}</p>
          <h3 className={`text-3xl font-bold ${valueClass} mt-1`}>{value}</h3>
        </div>
        <div className={`p-3 ${iconBg} rounded-full`}>
          <span className={`material-icons ${iconColor}`}>{icon}</span>
        </div>
      </div>
      {trend && (
        <p className={`text-xs ${trend.isPositive ? 'text-green-500' : 'text-red-500'} mt-4 flex items-center`}>
          <span className="material-icons text-xs mr-1">
            {trend.isPositive ? 'arrow_upward' : 'arrow_downward'}
          </span>
          {trend.value}
        </p>
      )}
      {footer && <p className="text-xs text-neutral-600 mt-4">{footer}</p>}
    </div>
  );
}
