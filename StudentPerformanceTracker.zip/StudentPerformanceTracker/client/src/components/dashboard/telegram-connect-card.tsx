import { useState, useEffect } from "react";
import { useAuth } from "@/lib/auth";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { nanoid } from "nanoid";

export function TelegramConnectCard() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isConnectModalOpen, setIsConnectModalOpen] = useState(false);
  const [verificationCode, setVerificationCode] = useState("");

  // Get current Telegram connection status
  const { data: telegramStatus, isLoading } = useQuery({
    queryKey: ["/api/telegram/status"],
    enabled: !!user,
  });

  // Generate a new verification code when modal opens
  useEffect(() => {
    if (isConnectModalOpen) {
      setVerificationCode(`GS${nanoid(8).toUpperCase()}`);
    }
  }, [isConnectModalOpen]);

  // Mutation to disconnect Telegram
  const disconnectMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("POST", "/api/telegram/unlink");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/telegram/status"] });
      toast({
        title: "Telegram отключен",
        description: "Ваш аккаунт успешно отвязан от Telegram",
      });
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Ошибка",
        description: error instanceof Error ? error.message : "Не удалось отключить Telegram",
      });
    },
  });

  const handleDisconnect = () => {
    disconnectMutation.mutate();
  };

  const handleConnect = () => {
    setIsConnectModalOpen(true);
  };

  if (isLoading) {
    return (
      <div className="bg-white rounded-lg shadow md:col-span-2 p-6">
        <div className="animate-pulse">
          <div className="h-6 bg-neutral-200 rounded w-1/2 mb-4"></div>
          <div className="h-32 bg-neutral-100 rounded mb-4"></div>
          <div className="h-10 bg-neutral-200 rounded w-1/4"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow md:col-span-2">
      <div className="p-6 border-b border-neutral-200">
        <h2 className="text-lg font-semibold font-heading">Telegram-бот для уведомлений</h2>
      </div>
      <div className="p-6">
        {telegramStatus?.connected ? (
          <div>
            <div className="flex items-center mb-6">
              <div className="w-12 h-12 rounded-full bg-accent bg-opacity-10 flex items-center justify-center mr-4">
                <span className="material-icons text-accent">send</span>
              </div>
              <div>
                <h3 className="font-medium text-neutral-800">Telegram подключен</h3>
                <p className="text-sm text-neutral-600 mt-1">
                  @{telegramStatus.username || "пользователь"}
                </p>
              </div>
            </div>
            
            <div className="bg-white border border-neutral-200 rounded-lg p-4 mb-6">
              <div className="flex justify-between items-center mb-4">
                <h4 className="font-medium text-neutral-800">Настройки уведомлений</h4>
              </div>
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-neutral-700">Новые оценки</span>
                  <Switch defaultChecked id="new-grades" />
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-neutral-700">Комментарии преподавателей</span>
                  <Switch defaultChecked id="comments" />
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-neutral-700">Предстоящие дедлайны</span>
                  <Switch defaultChecked id="deadlines" />
                </div>
              </div>
            </div>
            
            <div className="flex space-x-4">
              <Button 
                variant="outline" 
                onClick={handleDisconnect}
                disabled={disconnectMutation.isPending}
              >
                {disconnectMutation.isPending ? "Отключение..." : "Отключить"}
              </Button>
              <Button>
                Обновить настройки
              </Button>
            </div>
          </div>
        ) : (
          <div>
            <div className="flex items-center mb-4">
              <div className="w-12 h-12 rounded-full bg-neutral-100 flex items-center justify-center mr-4">
                <span className="material-icons text-neutral-400">send</span>
              </div>
              <div>
                <h3 className="font-medium text-neutral-800">Получайте уведомления в Telegram</h3>
                <p className="text-sm text-neutral-600 mt-1">Подключите бота для мгновенных уведомлений об оценках</p>
              </div>
            </div>
            <div className="bg-neutral-50 rounded-lg p-4 mb-4">
              <p className="text-sm text-neutral-700">1. Откройте <a href="https://t.me/GradeNotifierBot" target="_blank" rel="noopener noreferrer" className="text-primary">@GradeNotifierBot</a> в Telegram</p>
              <p className="text-sm text-neutral-700 mt-2">2. Отправьте боту свой логин и пароль от системы</p>
              <p className="text-sm text-neutral-700 mt-2">3. Дождитесь подтверждения привязки</p>
            </div>
            <Button onClick={handleConnect}>
              Подключить Telegram
            </Button>
          </div>
        )}
      </div>
      
      <Dialog open={isConnectModalOpen} onOpenChange={setIsConnectModalOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Подключение Telegram</DialogTitle>
          </DialogHeader>
          <div className="p-4">
            <div className="mb-6">
              <h4 className="font-medium text-neutral-800 mb-2">Для подключения уведомлений в Telegram:</h4>
              <ol className="list-decimal list-inside space-y-2 text-neutral-700">
                <li>Откройте Telegram и найдите бота <strong>@GradeNotifierBot</strong></li>
                <li>Нажмите кнопку "Начать" или отправьте команду /start</li>
                <li>Отправьте боту свой логин и пароль в формате: логин:пароль</li>
              </ol>
            </div>
            
            <div className="bg-neutral-50 p-4 rounded-lg mb-6 text-center">
              <p className="text-sm text-neutral-600 mb-2">Пример сообщения для бота:</p>
              <div className="bg-white border border-neutral-200 rounded-md p-3">
                <span className="font-mono text-sm">{user?.username}:ваш_пароль</span>
              </div>
              <p className="text-xs text-neutral-500 mt-2">Замените "ваш_пароль" на ваш текущий пароль от системы</p>
            </div>
            
            <div className="flex justify-end space-x-2">
              <Button variant="outline" onClick={() => setIsConnectModalOpen(false)}>
                Закрыть
              </Button>
              <Button>
                Проверить статус
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
