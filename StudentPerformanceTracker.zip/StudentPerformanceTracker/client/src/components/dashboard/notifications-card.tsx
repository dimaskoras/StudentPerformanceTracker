import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/lib/auth";
import { Notification } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";

export function NotificationsCard() {
  const { user } = useAuth();
  
  const { data: notifications, isLoading } = useQuery<Notification[]>({
    queryKey: ["/api/notifications/unread"],
    enabled: !!user,
  });

  const getNotificationBorder = (type: string) => {
    switch (type) {
      case "grade":
        return "border-primary";
      case "deadline":
        return "border-secondary";
      case "system":
        return "border-accent";
      default:
        return "border-neutral-300";
    }
  };

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case "grade":
        return "grade";
      case "deadline":
        return "event";
      case "system":
        return "send";
      default:
        return "info";
    }
  };

  const getNotificationIconColor = (type: string) => {
    switch (type) {
      case "grade":
        return "text-primary";
      case "deadline":
        return "text-secondary";
      case "system":
        return "text-accent";
      default:
        return "text-neutral-500";
    }
  };

  const formatDate = (dateString: string | Date) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('ru-RU', {
      day: "numeric",
      month: "long",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit"
    });
  };

  return (
    <div className="bg-white rounded-lg shadow md:col-span-1">
      <div className="p-6 border-b border-neutral-200">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold font-heading">Уведомления</h2>
          <Link href="/notifications">
            <a className="text-primary text-sm hover:underline">Все</a>
          </Link>
        </div>
      </div>
      <div className="p-4">
        <div className="space-y-4">
          {isLoading ? (
            [...Array(3)].map((_, index) => (
              <div key={index} className="p-3 border-l-4 border-neutral-200 animate-pulse">
                <div className="flex justify-between items-start">
                  <div className="w-full">
                    <Skeleton className="h-4 w-3/4 mb-2" />
                    <Skeleton className="h-3 w-1/2" />
                  </div>
                </div>
              </div>
            ))
          ) : !notifications?.length ? (
            <div className="text-center py-3 text-neutral-500">
              Нет новых уведомлений
            </div>
          ) : (
            notifications.slice(0, 3).map((notification) => (
              <div 
                key={notification.id} 
                className={`p-3 border-l-4 ${getNotificationBorder(notification.type)} bg-${notification.type}-light bg-opacity-5`}
              >
                <div className="flex justify-between items-start">
                  <div>
                    <p className="text-sm font-medium">{notification.title}</p>
                    <p className="text-xs text-neutral-500 mt-1">
                      {formatDate(notification.date)}
                    </p>
                  </div>
                  <span className={`material-icons ${getNotificationIconColor(notification.type)} text-sm`}>
                    {getNotificationIcon(notification.type)}
                  </span>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
