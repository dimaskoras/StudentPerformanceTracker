import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/lib/auth";
import { Grade } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";

interface GradeWithDetails extends Grade {
  courseName: string;
}

interface RecentGradesProps {
  limit?: number;
}

export function RecentGrades({ limit = 5 }: RecentGradesProps) {
  const { user } = useAuth();
  
  const { data: grades, isLoading } = useQuery<GradeWithDetails[]>({
    queryKey: [`/api/grades/recent/${user?.id}`, limit],
    enabled: !!user,
  });

  const getGradeColorClass = (value: number) => {
    switch (value) {
      case 5:
        return "bg-green-100 text-green-800";
      case 4:
        return "bg-yellow-100 text-yellow-800";
      case 3:
        return "bg-orange-100 text-orange-800";
      default:
        return "bg-red-100 text-red-800";
    }
  };

  const formatDate = (dateString: string | Date) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('ru-RU');
  };

  const renderSkeleton = () => (
    <>
      {[...Array(3)].map((_, index) => (
        <tr key={index} className="animate-pulse">
          <td className="px-6 py-4 whitespace-nowrap">
            <Skeleton className="h-5 w-40" />
          </td>
          <td className="px-6 py-4 whitespace-nowrap">
            <Skeleton className="h-5 w-32" />
          </td>
          <td className="px-6 py-4 whitespace-nowrap">
            <Skeleton className="h-5 w-24" />
          </td>
          <td className="px-6 py-4 whitespace-nowrap">
            <Skeleton className="h-6 w-6 rounded-full" />
          </td>
          <td className="px-6 py-4">
            <Skeleton className="h-5 w-full max-w-xs" />
          </td>
        </tr>
      ))}
    </>
  );

  return (
    <div className="bg-white rounded-lg shadow mb-8">
      <div className="p-6 border-b border-neutral-200">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold font-heading">Последние оценки</h2>
          <Link href="/grades">
            <a className="text-primary text-sm hover:underline">Показать все</a>
          </Link>
        </div>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-neutral-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                Дисциплина
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                Тип работы
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                Дата
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                Оценка
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                Комментарий
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-neutral-200">
            {isLoading ? (
              renderSkeleton()
            ) : !grades?.length ? (
              <tr>
                <td colSpan={5} className="px-6 py-8 text-center text-neutral-500">
                  Нет недавних оценок
                </td>
              </tr>
            ) : (
              grades.map((grade) => (
                <tr key={grade.id} className="hover:bg-neutral-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-neutral-800">
                      {grade.courseName}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-neutral-600">{grade.workType}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-neutral-600">{formatDate(grade.date)}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getGradeColorClass(grade.value)}`}>
                      {grade.value}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="text-sm text-neutral-600 max-w-xs truncate">
                      {grade.comment || "Нет комментария"}
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
