import { useState, useEffect } from "react";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogFooter,
  DialogDescription
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/lib/auth";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Loader2, Copy, Check } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface TelegramConnectModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

interface TelegramStatus {
  connected: boolean;
  username: string | null;
}

interface VerificationCode {
  code: string;
  expiresIn: string;
}

export function TelegramConnectModal({ open, onOpenChange }: TelegramConnectModalProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [connectionStatus, setConnectionStatus] = useState<"waiting" | "connected" | "error">("waiting");
  const [verificationCode, setVerificationCode] = useState<VerificationCode | null>(null);
  const [codeGenerating, setCodeGenerating] = useState(false);
  const [copied, setCopied] = useState(false);
  const [activeTab, setActiveTab] = useState("password");
  
  // Get current Telegram connection status
  const { data: telegramStatus, isLoading, refetch } = useQuery<TelegramStatus>({
    queryKey: ["/api/telegram/status"],
    enabled: open && !!user,
    refetchInterval: open ? 5000 : false, // Poll every 5 seconds while modal is open
  });
  
  // Generate verification code mutation
  const generateCodeMutation = useMutation({
    mutationFn: async () => {
      setCodeGenerating(true);
      const res = await apiRequest("POST", "/api/telegram/code/generate");
      const data = await res.json();
      return data as VerificationCode;
    },
    onSuccess: (data) => {
      setVerificationCode(data);
      setCodeGenerating(false);
      toast({
        title: "Код сгенерирован",
        description: "Код действителен в течение 10 минут",
      });
    },
    onError: (error) => {
      setCodeGenerating(false);
      toast({
        title: "Ошибка генерации кода",
        description: "Не удалось сгенерировать код верификации",
        variant: "destructive",
      });
    }
  });
  
  // Update connection status based on telegram status
  useEffect(() => {
    if (telegramStatus?.connected) {
      setConnectionStatus("connected");
    }
  }, [telegramStatus]);
  
  const handleCheckStatus = () => {
    refetch();
  };
  
  const handleClose = () => {
    onOpenChange(false);
  };
  
  const handleGenerateCode = () => {
    generateCodeMutation.mutate();
  };
  
  const handleCopyCode = () => {
    if (verificationCode) {
      navigator.clipboard.writeText(verificationCode.code);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
      
      toast({
        title: "Код скопирован",
        description: "Код верификации скопирован в буфер обмена",
      });
    }
  };
  
  const getStatusBadge = () => {
    switch (connectionStatus) {
      case "connected":
        return <span className="px-2 py-1 bg-green-100 text-green-800 text-xs rounded-full">Подключен</span>;
      case "error":
        return <span className="px-2 py-1 bg-red-100 text-red-800 text-xs rounded-full">Ошибка</span>;
      default:
        return <span className="px-2 py-1 bg-yellow-100 text-yellow-800 text-xs rounded-full">Ожидание</span>;
    }
  };

  if (telegramStatus?.connected) {
    return (
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Подключение к Telegram</DialogTitle>
            <DialogDescription>
              Ваш аккаунт уже подключен к Telegram
            </DialogDescription>
          </DialogHeader>
          
          <div className="p-4">
            <div className="bg-green-50 border border-green-100 rounded-lg p-4 mb-4 flex items-center space-x-3">
              <div className="h-10 w-10 bg-green-100 rounded-full flex items-center justify-center">
                <Check className="h-5 w-5 text-green-600" />
              </div>
              <div>
                <h3 className="font-medium text-green-800">Аккаунт подключен</h3>
                <p className="text-sm text-green-600">
                  {telegramStatus.username ? `@${telegramStatus.username}` : "Telegram успешно подключен"}
                </p>
              </div>
            </div>
            
            <p className="text-sm text-neutral-600 mb-4">
              Вы уже подключили Telegram к вашей учетной записи. Теперь вы будете получать уведомления о новых оценках и других событиях.
            </p>
            
            <div className="rounded-lg bg-yellow-50 p-3 border border-yellow-100">
              <p className="text-sm text-yellow-700">
                Если вы хотите отключить Telegram от вашей учетной записи, нажмите кнопку "Отключить Telegram".
              </p>
            </div>
          </div>
          
          <DialogFooter className="flex justify-between sm:justify-between">
            <Button variant="outline" onClick={handleClose}>
              Закрыть
            </Button>
            <Button variant="destructive" onClick={() => {
              // Отключение Telegram (API-запрос на отключение)
              apiRequest("POST", "/api/telegram/unlink")
                .then(() => {
                  toast({
                    title: "Telegram отключен",
                    description: "Ваш аккаунт был отключен от Telegram",
                  });
                  refetch();
                })
                .catch((error) => {
                  toast({
                    title: "Ошибка отключения",
                    description: "Не удалось отключить Telegram",
                    variant: "destructive",
                  });
                });
            }}>
              Отключить Telegram
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Подключение Telegram</DialogTitle>
          <DialogDescription>
            Выберите удобный способ подключения Telegram для получения уведомлений
          </DialogDescription>
        </DialogHeader>
        
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid grid-cols-2 w-full mb-4">
            <TabsTrigger value="password">Логин и пароль</TabsTrigger>
            <TabsTrigger value="code">Код подтверждения</TabsTrigger>
          </TabsList>
          
          <TabsContent value="password" className="mt-0">
            <div className="p-2">
              <div className="mb-6">
                <h4 className="font-medium text-neutral-800 mb-2">Для подключения с логином и паролем:</h4>
                <ol className="list-decimal list-inside space-y-2 text-neutral-700">
                  <li>Откройте Telegram и найдите бота <strong>@GradeNotifier_Bot</strong></li>
                  <li>Нажмите кнопку "Начать" или отправьте команду /start</li>
                  <li>Отправьте боту ваши логин и пароль в формате, указанном ниже</li>
                </ol>
              </div>
              
              <div className="bg-neutral-50 p-4 rounded-lg mb-6 text-center">
                <p className="text-sm text-neutral-600 mb-2">Отправьте боту сообщение в формате:</p>
                <div className="bg-white border border-neutral-200 rounded-md p-3">
                  {user && <span className="font-mono text-lg font-bold tracking-wide">{user.username}:password</span>}
                </div>
                <p className="text-xs text-neutral-500 mt-2">Где password - ваш пароль от этой системы</p>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="code" className="mt-0">
            <div className="p-2">
              <div className="mb-6">
                <h4 className="font-medium text-neutral-800 mb-2">Для подключения с кодом подтверждения:</h4>
                <ol className="list-decimal list-inside space-y-2 text-neutral-700">
                  <li>Нажмите кнопку "Сгенерировать код" ниже</li>
                  <li>Откройте Telegram и найдите бота <strong>@GradeNotifier_Bot</strong></li>
                  <li>Нажмите кнопку "Начать" или отправьте команду /start</li>
                  <li>Отправьте боту код в формате, указанном ниже</li>
                </ol>
              </div>
              
              <div className="mb-4">
                <Button 
                  className="w-full"
                  onClick={handleGenerateCode}
                  disabled={codeGenerating || !!verificationCode}
                >
                  {codeGenerating ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Генерация...
                    </>
                  ) : verificationCode ? (
                    "Код уже сгенерирован"
                  ) : (
                    "Сгенерировать код"
                  )}
                </Button>
              </div>
              
              {verificationCode && (
                <div className="bg-neutral-50 p-4 rounded-lg mb-6">
                  <div className="flex items-center justify-between mb-2">
                    <p className="text-sm text-neutral-600">Отправьте боту сообщение в формате:</p>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="h-8 w-8"
                      onClick={handleCopyCode}
                    >
                      {copied ? (
                        <Check className="h-4 w-4" />
                      ) : (
                        <Copy className="h-4 w-4" />
                      )}
                    </Button>
                  </div>
                  <div className="bg-white border border-neutral-200 rounded-md p-3 text-center mb-2">
                    <span className="font-mono text-lg font-bold tracking-wide">код:{verificationCode.code}</span>
                  </div>
                  <p className="text-xs text-neutral-500 text-center">
                    Код действителен в течение {verificationCode.expiresIn}
                  </p>
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>
        
        <div className="flex items-center justify-between mb-4 px-4">
          <span className="text-neutral-700 text-sm">Статус подключения:</span>
          {getStatusBadge()}
        </div>
        
        <DialogFooter className="flex justify-between sm:justify-between">
          <Button variant="outline" onClick={handleClose}>
            Отмена
          </Button>
          <Button onClick={handleCheckStatus} disabled={connectionStatus === "connected"}>
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Проверка...
              </>
            ) : connectionStatus === "connected" ? (
              "Подключено"
            ) : (
              "Проверить статус"
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}