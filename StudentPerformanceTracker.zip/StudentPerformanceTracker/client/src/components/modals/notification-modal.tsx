import { useState, useEffect } from "react";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogFooter
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Notification, Grade } from "@shared/schema";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface NotificationModalProps {
  notification: Notification | null;
  grade?: Grade & { courseName?: string };
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function NotificationModal({ 
  notification, 
  grade, 
  open, 
  onOpenChange 
}: NotificationModalProps) {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  
  // Mark notification as read when opened
  const markAsReadMutation = useMutation({
    mutationFn: async () => {
      if (!notification) return;
      await apiRequest("PATCH", `/api/notifications/${notification.id}/read`, { isRead: true });
      
      // If notification is about a grade, also mark the grade as read
      if (notification.type === "grade" && notification.relatedId) {
        await apiRequest("PATCH", `/api/grades/${notification.relatedId}/read`, { isRead: true });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/notifications"] });
      queryClient.invalidateQueries({ queryKey: ["/api/notifications/unread"] });
      queryClient.invalidateQueries({ queryKey: ["/api/grades"] });
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Ошибка",
        description: error instanceof Error ? error.message : "Не удалось отметить уведомление как прочитанное",
      });
    },
  });
  
  // Mark as read when opened
  useEffect(() => {
    if (open && notification && !notification.isRead) {
      markAsReadMutation.mutate();
    }
  }, [open, notification]);
  
  const handleClose = () => {
    onOpenChange(false);
  };
  
  const formatDate = (dateString: string | Date) => {
    if (!dateString) return "";
    const date = new Date(dateString);
    return date.toLocaleDateString('ru-RU');
  };
  
  // Get title and content based on notification type
  const getTitle = () => {
    if (!notification) return "";
    
    return notification.title || 
      (notification.type === "grade" 
        ? "Новая оценка" 
        : notification.type === "deadline" 
          ? "Предстоящий дедлайн" 
          : "Уведомление");
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>{getTitle()}</DialogTitle>
        </DialogHeader>
        
        <div className="py-4">
          {notification && notification.type === "grade" && grade ? (
            <>
              <div className="mb-4">
                <p className="text-neutral-700">Вы получили новую оценку по предмету <strong>{grade.courseName}</strong>.</p>
              </div>
              <div className="bg-neutral-50 p-4 rounded-lg mb-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-neutral-500">Тип работы:</span>
                  <span className="text-sm font-medium">{grade.workType}</span>
                </div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-neutral-500">Оценка:</span>
                  <span className={`text-sm font-medium ${
                    grade.value === 5 ? "grade-excellent" : 
                    grade.value === 4 ? "grade-good" : 
                    grade.value === 3 ? "grade-satisfactory" : 
                    "grade-unsatisfactory"
                  }`}>{grade.value}</span>
                </div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-neutral-500">Дата:</span>
                  <span className="text-sm font-medium">{formatDate(grade.date)}</span>
                </div>
                {grade.comment && (
                  <div className="mt-3">
                    <span className="text-sm text-neutral-500">Комментарий преподавателя:</span>
                    <p className="text-sm mt-1 text-neutral-700">{grade.comment}</p>
                  </div>
                )}
              </div>
            </>
          ) : notification ? (
            <div className="bg-neutral-50 p-4 rounded-lg mb-4">
              <p className="text-sm text-neutral-700">{notification.message}</p>
              <p className="text-xs text-neutral-500 mt-2">
                {formatDate(notification.date)}
              </p>
            </div>
          ) : (
            <div className="text-neutral-500 text-center py-4">
              Данные уведомления не найдены
            </div>
          )}
        </div>
        
        <DialogFooter>
          <Button onClick={handleClose} disabled={isLoading}>
            Понятно
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
