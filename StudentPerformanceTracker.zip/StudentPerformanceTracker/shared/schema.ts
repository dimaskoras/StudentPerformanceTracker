import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User model (students and teachers/admins)
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  firstName: text("firstName").notNull(),
  lastName: text("lastName").notNull(),
  email: text("email").notNull(),
  role: text("role").notNull().default("student"), // "student" or "teacher"
  group: text("group"), // For students only
  telegramId: text("telegramId"), // When user connects Telegram
  telegramUsername: text("telegramUsername"),
  telegramConnected: boolean("telegramConnected").default(false),
});

// Course model (subjects)
export const courses = pgTable("courses", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  teacherId: integer("teacherId").notNull(), // Reference to teacher user
});

// Grade model
export const grades = pgTable("grades", {
  id: serial("id").primaryKey(),
  studentId: integer("studentId").notNull(), // Reference to student user
  courseId: integer("courseId").notNull(), // Reference to course
  value: integer("value").notNull(), // 2-5 or can be null for absence
  workType: text("workType").notNull(), // "lab", "exam", "homework", etc.
  comment: text("comment"),
  date: timestamp("date").notNull().defaultNow(),
  isRead: boolean("isRead").default(false), // Whether the student has read this grade
});

// Notification model
export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  userId: integer("userId").notNull(), // Reference to user
  title: text("title").notNull(),
  message: text("message").notNull(),
  type: text("type").notNull(), // "grade", "deadline", "system", etc.
  isRead: boolean("isRead").default(false),
  date: timestamp("date").notNull().defaultNow(),
  relatedId: integer("relatedId"), // Optional reference to related entity (e.g., grade id)
});

// ZOD schemas for validation
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  firstName: true,
  lastName: true,
  email: true,
  role: true,
  group: true,
});

export const insertCourseSchema = createInsertSchema(courses).pick({
  name: true,
  description: true,
  teacherId: true,
});

export const insertGradeSchema = createInsertSchema(grades).pick({
  studentId: true,
  courseId: true,
  value: true,
  workType: true,
  comment: true,
  date: true,
});

export const insertNotificationSchema = createInsertSchema(notifications).pick({
  userId: true,
  title: true,
  message: true,
  type: true,
  relatedId: true,
});

export const loginSchema = z.object({
  username: z.string().min(1, { message: "Логин обязателен" }),
  password: z.string().min(1, { message: "Пароль обязателен" }),
});

export const telegramLinkSchema = z.object({
  username: z.string().min(1, { message: "Логин обязателен" }),
  password: z.string().min(1, { message: "Пароль обязателен" }),
  telegramId: z.string().min(1, { message: "Telegram ID обязателен" }),
  telegramUsername: z.string().optional(),
});

export const telegramCodeLinkSchema = z.object({
  code: z.string().min(1, { message: "Код подтверждения обязателен" }),
  telegramId: z.string().min(1, { message: "Telegram ID обязателен" }),
  telegramUsername: z.string().optional(),
});

// Type exports
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Course = typeof courses.$inferSelect;
export type InsertCourse = z.infer<typeof insertCourseSchema>;
export type Grade = typeof grades.$inferSelect;
export type InsertGrade = z.infer<typeof insertGradeSchema>;
export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = z.infer<typeof insertNotificationSchema>;
export type Login = z.infer<typeof loginSchema>;
export type TelegramLink = z.infer<typeof telegramLinkSchema>;
export type TelegramCodeLink = z.infer<typeof telegramCodeLinkSchema>;

// Helper interface for UserWithStats (extended user info)
export interface UserWithStats extends User {
  gradesCount?: number;
  averageGrade?: number;
  absencesCount?: number;
  telegramConnected: boolean;
}
