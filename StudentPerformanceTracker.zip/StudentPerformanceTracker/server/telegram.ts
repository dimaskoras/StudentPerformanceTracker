import { Telegraf, Context } from "telegraf";
import { IStorage } from "./storage";
import { message } from "telegraf/filters";

// Глобальный экземпляр бота для использования в других частях приложения
let botInstance: Telegraf | null = null;

// Dictionary to store authentication attempts by Telegram user ID
interface AuthAttempt {
  username: string;
  password: string;
  timestamp: number;
}

// Dictionary to store verification code attempts
interface CodeAttempt {
  code: string;
  timestamp: number;
}

const authAttempts = new Map<number, AuthAttempt>();
const codeAttempts = new Map<number, CodeAttempt>();

// Функция для отправки сообщений пользователю через бота
export async function sendTelegramMessage(telegramId: string, message: string): Promise<boolean> {
  if (!botInstance) {
    console.log("Cannot send Telegram message: bot instance not initialized");
    return false;
  }

  try {
    await botInstance.telegram.sendMessage(telegramId, message);
    return true;
  } catch (error) {
    console.error("Error sending Telegram message:", error);
    return false;
  }
}

// Configure and set up the Telegram bot
export function configureBot(bot: Telegraf, storage: IStorage) {
  // Сохраняем глобальный экземпляр бота
  botInstance = bot;
  // Start command handler
  bot.start(async (ctx) => {
    ctx.reply(
      "Добро пожаловать в систему учета успеваемости студентов! 👋\n\n" +
      "Есть два способа привязать аккаунт:\n\n" +
      "1️⃣ Отправьте мне ваш логин и пароль от системы в формате:\n" +
      "логин:пароль\n" +
      "Например: student1:password\n\n" +
      "2️⃣ Используйте код подтверждения из личного кабинета на сайте:\n" +
      "XXXX_XX-XXXXX\n" +
      "Например: GS85_B-Cm6v"
    );
  });

  // Help command handler
  bot.help((ctx) => {
    ctx.reply(
      "🔹 /start - Начать работу с ботом\n" +
      "🔹 /help - Показать справку\n" +
      "🔹 /status - Проверить статус подключения\n\n" +
      "Для привязки аккаунта есть два способа:\n\n" +
      "1️⃣ Отправьте логин и пароль в формате: логин:пароль\n" +
      "2️⃣ Используйте код подтверждения из личного кабинета: XXXX_XX-XXXXX"
    );
  });

  // Status command handler
  bot.command("status", async (ctx) => {
    const telegramId = ctx.from.id.toString();
    const user = await findUserByTelegramId(storage, telegramId);
    
    if (user) {
      ctx.reply(
        `✅ Ваш аккаунт привязан к системе\n\n` +
        `Имя: ${user.firstName} ${user.lastName}\n` +
        `Роль: ${user.role === "student" ? "Студент" : "Преподаватель"}\n` +
        `${user.role === "student" ? `Группа: ${user.group}` : ""}`
      );
    } else {
      ctx.reply(
        "⚠️ Ваш аккаунт не привязан к системе\n\n" +
        "Чтобы привязать аккаунт, есть два способа:\n\n" +
        "1️⃣ Отправьте логин и пароль в формате: логин:пароль\n" +
        "2️⃣ Используйте код подтверждения из личного кабинета: XXXX_XX-XXXXX"
      );
    }
  });

  // Handle login:password messages and verification codes
  bot.on(message("text"), async (ctx) => {
    const text = ctx.message.text.trim();
    const telegramId = ctx.from.id.toString();
    const telegramUsername = ctx.from.username;
    
    // Проверяем формат сообщения - код подтверждения или логин/пароль
    // Распознаем код подтверждения по формату XXXX_XX-XXXXX или через префикс "код:"/"code:"
    const isCodeWithPrefix = text.toLowerCase().startsWith("код:") || text.toLowerCase().startsWith("code:");
    const hasCodeFormat = /^[A-Z0-9]{4}_[A-Z0-9]{2}-[A-Z0-9]{5}$/.test(text.trim());
    
    if (isCodeWithPrefix || hasCodeFormat) {
      // Обработка кода подтверждения
      let code;
      if (isCodeWithPrefix) {
        code = text.substring(text.indexOf(":") + 1).trim();
      } else {
        code = text.trim(); // код введен напрямую без префикса
      }
      
      if (!code) {
        ctx.reply("⚠️ Код подтверждения не может быть пустым. Пожалуйста, укажите код из личного кабинета.");
        return;
      }
      
      // Сохраняем попытку аутентификации с кодом
      codeAttempts.set(ctx.from.id, {
        code,
        timestamp: Date.now()
      });
      
      try {
        // Отправляем запрос на сервер для проверки кода
        // Формируем URL с учетом всех возможных вариантов хостинга
        const baseUrl = process.env.BASE_URL || `http://localhost:${process.env.PORT || 5000}`;
        
        console.log(`Attempting to link with code: ${code} for Telegram ID: ${telegramId}`);
        
        const response = await fetch(`${baseUrl}/api/telegram/code/link`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            code,
            telegramId,
            telegramUsername
          })
        });
        
        const responseData = await response.json();
        
        if (!response.ok) {
          ctx.reply(`❌ ${responseData.message || "Неверный код подтверждения. Пожалуйста, проверьте код и попробуйте снова."}`);
          return;
        }
        
        // Код успешно подтвержден
        ctx.reply(
          `✅ Аккаунт ${responseData.username} успешно привязан к Telegram!\n\n` +
          `Теперь вы будете получать уведомления о новых оценках и других событиях.`
        );
        
      } catch (error) {
        console.error("Telegram bot error with verification code:", error);
        ctx.reply("❌ Произошла ошибка при проверке кода. Пожалуйста, попробуйте позже.");
      }
      
      return;
    }
    
    // Логин и пароль
    const credentials = parseCredentials(text);
    
    if (!credentials) {
      ctx.reply(
        "⚠️ Неверный формат сообщения\n\n" +
        "Для привязки аккаунта:\n\n" +
        "1️⃣ Отправьте логин и пароль в формате: логин:пароль\n" +
        "Например: student1:password\n\n" +
        "2️⃣ Или код подтверждения из личного кабинета: XXXX_XX-XXXXX"
      );
      return;
    }
    
    const { username, password } = credentials;
    
    // Store auth attempt for processing
    authAttempts.set(ctx.from.id, {
      username,
      password,
      timestamp: Date.now()
    });
    
    try {
      // Try to authenticate and link the user
      const user = await storage.getUserByUsername(username);
      
      if (!user) {
        ctx.reply("❌ Ошибка авторизации: пользователь с таким логином не найден. Пожалуйста, проверьте правильность введенных данных.");
        return;
      }
      
      if (user.password !== password) {
        ctx.reply("❌ Ошибка авторизации: неверный пароль. Пожалуйста, убедитесь, что вы правильно ввели пароль.");
        return;
      }
      
      // Check if already connected
      if (user.telegramConnected && user.telegramId) {
        if (user.telegramId === telegramId) {
          ctx.reply("ℹ️ Ваш аккаунт уже привязан к системе.");
        } else {
          ctx.reply("⚠️ Этот аккаунт уже привязан к другому пользователю Telegram.");
        }
        return;
      }
      
      // Link user to Telegram
      await storage.updateUser(user.id, {
        telegramId,
        telegramUsername,
        telegramConnected: true
      });
      
      // Send notification
      await storage.createNotification({
        userId: user.id,
        title: "Telegram подключен",
        message: "Ваш аккаунт был успешно привязан к Telegram",
        type: "system",
        relatedId: null
      });
      
      // Confirm successful linking
      ctx.reply(
        `✅ Ваш аккаунт успешно привязан к системе!\n\n` +
        `Имя: ${user.firstName} ${user.lastName}\n` +
        `Роль: ${user.role === "student" ? "Студент" : "Преподаватель"}\n` +
        `${user.role === "student" ? `Группа: ${user.group}` : ""}\n\n` +
        `Теперь вы будете получать уведомления о новых оценках и других событиях.`
      );
    } catch (error) {
      console.error("Telegram bot error:", error);
      ctx.reply("❌ Произошла ошибка при обработке запроса. Пожалуйста, попробуйте позже.");
    }
  });

  // Launch the bot only if we have a real token (not dummy)
  if (process.env.TELEGRAM_BOT_TOKEN && 
      process.env.TELEGRAM_BOT_TOKEN !== "dummy_token_for_development") {
    try {
      bot.launch();
      console.log("Telegram bot started with real token");
      
      // Enable graceful stop
      process.once('SIGINT', () => bot.stop('SIGINT'));
      process.once('SIGTERM', () => bot.stop('SIGTERM'));
    } catch (error) {
      console.error("Failed to start Telegram bot:", error);
    }
  } else {
    console.log("Telegram bot not started (using dummy token for development)");
  }
}

// Helper functions
async function findUserByTelegramId(storage: IStorage, telegramId: string): Promise<any | null> {
  const users = await storage.getUsers();
  return users.find(user => user.telegramId === telegramId) || null;
}

function parseCredentials(text: string): { username: string, password: string } | null {
  const parts = text.split(':');
  if (parts.length !== 2) return null;
  
  const [username, password] = parts;
  if (!username.trim() || !password.trim()) return null;
  
  return { username: username.trim(), password: password.trim() };
}
