import { User, InsertUser, Course, InsertCourse, Grade, InsertGrade, Notification, InsertNotification } from "@shared/schema";
import { DatabaseStorage } from "./database-storage";

export interface IStorage {
  // Свойство для сессионного хранилища
  sessionStore: any;
  
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, data: Partial<User>): Promise<User | undefined>;
  deleteUser(id: number): Promise<boolean>;
  getUsers(role?: string): Promise<User[]>;
  
  // Course methods
  getCourse(id: number): Promise<Course | undefined>;
  createCourse(course: InsertCourse): Promise<Course>;
  getCoursesByTeacher(teacherId: number): Promise<Course[]>;
  getAllCourses(): Promise<Course[]>;
  
  // Grade methods
  getGrade(id: number): Promise<Grade | undefined>;
  createGrade(grade: InsertGrade): Promise<Grade>;
  getGradesByStudent(studentId: number): Promise<Grade[]>;
  getGradesByCourse(courseId: number): Promise<Grade[]>;
  getGradesByStudentAndCourse(studentId: number, courseId: number): Promise<Grade[]>;
  getRecentGradesByStudent(studentId: number, limit?: number): Promise<Grade[]>;
  updateGradeRead(id: number, isRead: boolean): Promise<Grade | undefined>;
  
  // Notification methods
  getNotification(id: number): Promise<Notification | undefined>;
  createNotification(notification: InsertNotification): Promise<Notification>;
  getNotificationsByUser(userId: number): Promise<Notification[]>;
  getUnreadNotificationsByUser(userId: number): Promise<Notification[]>;
  updateNotificationRead(id: number, isRead: boolean): Promise<Notification | undefined>;
  
  // Statistics methods
  getStudentsWithStats(): Promise<any[]>;
  getStudentStats(studentId: number): Promise<{
    averageGrade: number;
    uncompletedCourses: number;
    newGradesCount: number;
    attendancePercentage: number;
  }>;
  
  // Инициализация данных
  initializeData?(): Promise<void>;
}

// Используем хранилище в базе данных
export const storage = new DatabaseStorage();