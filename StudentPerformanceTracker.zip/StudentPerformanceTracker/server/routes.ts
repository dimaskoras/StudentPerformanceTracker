import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { Telegraf } from "telegraf";
import session from "express-session";
import { configureBot } from "./telegram";
import { loginSchema, telegramLinkSchema, telegramCodeLinkSchema, insertUserSchema } from "@shared/schema";
import { z } from "zod";
import { ZodError } from "zod-validation-error";
import dotenv from "dotenv";
import { nanoid } from "nanoid";
import { setupAuth } from "./auth";
import { db } from "./db";
import { users, courses, grades, notifications } from "@shared/schema";

// Загружаем переменные среды из .env файла
dotenv.config();

declare module "express-session" {
  interface SessionData {
    userId: number;
    role: string;
  }
}

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);
  
  // Хранилище для кодов подтверждения Telegram
  const telegramVerificationCodes: Map<number, { code: string, expires: Date }> = new Map();

  try {
    // Инициализация базы данных и таблиц
    console.log("Инициализация базы данных...");
    
    // Инициализируем базу данных с тестовыми данными
    if (storage.initializeData) {
      await storage.initializeData();
    }
    
    console.log("База данных успешно инициализирована");
  } catch (error) {
    console.error("Ошибка при инициализации базы данных:", error);
  }

  // Настраиваем аутентификацию
  setupAuth(app);

  // Authentication middleware
  const isAuthenticated = (req: Request, res: Response, next: Function) => {
    if (req.isAuthenticated()) {
      return next();
    }
    return res.status(401).json({ message: "Требуется авторизация" });
  };

  // Role-based access middleware
  const hasRole = (role: string) => (req: Request, res: Response, next: Function) => {
    if (req.isAuthenticated() && (req.user as any).role === role) {
      return next();
    }
    return res.status(403).json({ message: "Доступ запрещен" });
  };

  // Маршруты аутентификации уже настроены в auth.ts

  // Update own profile
  app.patch("/api/profile", isAuthenticated, async (req, res) => {
    try {
      const userId = (req.user as any).id;
      
      // Разрешаем обновлять только некоторые поля профиля
      const allowedFields = ['firstName', 'lastName', 'email'];
      const updateData: any = {};
      
      Object.keys(req.body).forEach(key => {
        if (allowedFields.includes(key)) {
          updateData[key] = req.body[key];
        }
      });
      
      console.log("Updating user profile with data:", JSON.stringify(updateData));
      
      const updatedUser = await storage.updateUser(userId, updateData);
      if (!updatedUser) {
        return res.status(500).json({ message: "Не удалось обновить профиль" });
      }
      
      // Return user without password
      const { password, ...userDataWithoutPassword } = updatedUser;
      return res.status(200).json(userDataWithoutPassword);
    } catch (error) {
      console.error("Error updating profile:", error);
      return res.status(500).json({ message: "Внутренняя ошибка сервера" });
    }
  });
  
  // Change password
  app.patch("/api/profile/password", isAuthenticated, async (req, res) => {
    try {
      const userId = (req.user as any).id;
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "Пользователь не найден" });
      }
      
      const { currentPassword, newPassword } = req.body;
      
      // Проверяем текущий пароль
      // В реальном приложении здесь будет сравнение хешей
      if (currentPassword !== user.password) {
        return res.status(401).json({ message: "Неверный текущий пароль" });
      }
      
      // Обновляем пароль
      const updatedUser = await storage.updateUser(userId, { password: newPassword });
      if (!updatedUser) {
        return res.status(500).json({ message: "Не удалось обновить пароль" });
      }
      
      return res.status(200).json({ message: "Пароль успешно изменен" });
    } catch (error) {
      console.error("Error updating password:", error);
      return res.status(500).json({ message: "Внутренняя ошибка сервера" });
    }
  });

  // User routes
  app.get("/api/users/students", isAuthenticated, async (req, res) => {
    const students = await storage.getUsers("student");
    const studentsWithoutPasswords = students.map(student => {
      const { password, ...userData } = student;
      return userData;
    });
    return res.json(studentsWithoutPasswords);
  });

  app.get("/api/users/students/stats", isAuthenticated, hasRole("teacher"), async (req, res) => {
    const studentsWithStats = await storage.getStudentsWithStats();
    const studentsWithoutPasswords = studentsWithStats.map(student => {
      const { password, ...userData } = student;
      return userData;
    });
    return res.json(studentsWithoutPasswords);
  });
  
  // Get all users
  app.get("/api/users", isAuthenticated, hasRole("teacher"), async (req, res) => {
    const role = req.query.role as string | undefined;
    const users = await storage.getUsers(role);
    const usersWithoutPasswords = users.map(user => {
      const { password, ...userData } = user;
      return userData;
    });
    return res.json(usersWithoutPasswords);
  });
  
  // Create new user
  app.post("/api/users", isAuthenticated, hasRole("teacher"), async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if username already exists
      const existingUser = await storage.getUserByUsername(userData.username);
      if (existingUser) {
        return res.status(400).json({ message: "Пользователь с таким логином уже существует" });
      }
      
      const newUser = await storage.createUser(userData);
      
      // Return user without password
      const { password, ...userDataWithoutPassword } = newUser;
      return res.status(200).json(userDataWithoutPassword);
    } catch (error) {
      console.error("Error creating user:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Неверный формат данных пользователя", 
          errors: error.errors 
        });
      }
      return res.status(500).json({ message: "Ошибка при создании пользователя" });
    }
  });
  
  // Update user (edit by admin)
  app.patch("/api/users/:id", isAuthenticated, hasRole("teacher"), async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Некорректный ID пользователя" });
      }
      
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "Пользователь не найден" });
      }
      
      // Don't allow changing own role if you're a teacher
      if (userId === (req.user as any).id && req.body.role && req.body.role !== user.role) {
        return res.status(400).json({ message: "Нельзя изменить собственную роль" });
      }
      
      // Update user
      const updatedUser = await storage.updateUser(userId, req.body);
      if (!updatedUser) {
        return res.status(500).json({ message: "Не удалось обновить пользователя" });
      }
      
      // Return user without password
      const { password, ...userDataWithoutPassword } = updatedUser;
      return res.status(200).json(userDataWithoutPassword);
    } catch (error) {
      console.error("Error updating user:", error);
      return res.status(500).json({ message: "Внутренняя ошибка сервера" });
    }
  });
  
  // Delete user
  app.delete("/api/users/:id", isAuthenticated, hasRole("teacher"), async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Некорректный ID пользователя" });
      }
      
      // Prevent deleting your own account
      if (userId === (req.user as any).id) {
        return res.status(400).json({ message: "Нельзя удалить собственную учетную запись" });
      }
      
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "Пользователь не найден" });
      }
      
      // Add method to storage to delete user
      const deleted = await storage.deleteUser(userId);
      if (!deleted) {
        return res.status(500).json({ message: "Не удалось удалить пользователя" });
      }
      
      return res.status(200).json({ message: "Пользователь успешно удален" });
    } catch (error) {
      console.error("Error deleting user:", error);
      return res.status(500).json({ message: "Ошибка при удалении пользователя" });
    }
  });

  // Course routes
  app.get("/api/courses", isAuthenticated, async (req, res) => {
    const courses = await storage.getAllCourses();
    return res.json(courses);
  });

  app.get("/api/courses/:id", isAuthenticated, async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Некорректный ID курса" });
    }
    
    const course = await storage.getCourse(id);
    if (!course) {
      return res.status(404).json({ message: "Курс не найден" });
    }
    
    return res.json(course);
  });

  // Grade routes
  app.get("/api/grades/student/:studentId", isAuthenticated, async (req, res) => {
    const studentId = parseInt(req.params.studentId);
    if (isNaN(studentId)) {
      return res.status(400).json({ message: "Некорректный ID студента" });
    }
    
    // Only allow students to view their own grades, or teachers to view any student's grades
    if ((req.user as any).role === "student" && (req.user as any).id !== studentId) {
      return res.status(403).json({ message: "Доступ запрещен" });
    }
    
    const grades = await storage.getGradesByStudent(studentId);
    
    // Fetch course details for each grade
    const gradesWithCourseDetails = await Promise.all(grades.map(async (grade) => {
      const course = await storage.getCourse(grade.courseId);
      return {
        ...grade,
        courseName: course?.name || "Неизвестный курс"
      };
    }));
    
    return res.json(gradesWithCourseDetails);
  });

  app.get("/api/grades/recent/:studentId", isAuthenticated, async (req, res) => {
    const studentId = parseInt(req.params.studentId);
    if (isNaN(studentId)) {
      return res.status(400).json({ message: "Некорректный ID студента" });
    }
    
    // Only allow students to view their own recent grades, or teachers to view any student's grades
    if ((req.user as any).role === "student" && (req.user as any).id !== studentId) {
      return res.status(403).json({ message: "Доступ запрещен" });
    }
    
    const limit = req.query.limit ? parseInt(req.query.limit as string) : 5;
    const recentGrades = await storage.getRecentGradesByStudent(studentId, limit);
    
    // Fetch course details for each grade
    const gradesWithCourseDetails = await Promise.all(recentGrades.map(async (grade) => {
      const course = await storage.getCourse(grade.courseId);
      return {
        ...grade,
        courseName: course?.name || "Неизвестный курс"
      };
    }));
    
    return res.json(gradesWithCourseDetails);
  });

  app.post("/api/grades", isAuthenticated, hasRole("teacher"), async (req, res) => {
    try {
      const grade = req.body;
      const newGrade = await storage.createGrade(grade);
      
      return res.status(201).json(newGrade);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Некорректные данные оценки", errors: error.errors });
      }
      return res.status(500).json({ message: "Внутренняя ошибка сервера" });
    }
  });

  app.patch("/api/grades/:id/read", isAuthenticated, async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Некорректный ID оценки" });
    }
    
    const grade = await storage.getGrade(id);
    if (!grade) {
      return res.status(404).json({ message: "Оценка не найдена" });
    }
    
    // Only allow students to mark their own grades as read
    if ((req.user as any).role === "student" && (req.user as any).id !== grade.studentId) {
      return res.status(403).json({ message: "Доступ запрещен" });
    }
    
    const updatedGrade = await storage.updateGradeRead(id, true);
    return res.json(updatedGrade);
  });

  // Notification routes
  app.get("/api/notifications", isAuthenticated, async (req, res) => {
    const userId = (req.user as any).id;
    const notifications = await storage.getNotificationsByUser(userId);
    return res.json(notifications);
  });

  app.get("/api/notifications/unread", isAuthenticated, async (req, res) => {
    const userId = (req.user as any).id;
    const notifications = await storage.getUnreadNotificationsByUser(userId);
    return res.json(notifications);
  });

  app.patch("/api/notifications/:id/read", isAuthenticated, async (req, res) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Некорректный ID уведомления" });
    }
    
    const notification = await storage.getNotification(id);
    if (!notification) {
      return res.status(404).json({ message: "Уведомление не найдено" });
    }
    
    // Only allow users to mark their own notifications as read
    if ((req.user as any).id !== notification.userId) {
      return res.status(403).json({ message: "Доступ запрещен" });
    }
    
    const updatedNotification = await storage.updateNotificationRead(id, true);
    return res.json(updatedNotification);
  });

  // Statistics routes
  app.get("/api/stats/student/:studentId", isAuthenticated, async (req, res) => {
    const studentId = parseInt(req.params.studentId);
    if (isNaN(studentId)) {
      return res.status(400).json({ message: "Некорректный ID студента" });
    }
    
    // Only allow students to view their own statistics, or teachers to view any student's statistics
    if ((req.user as any).role === "student" && (req.user as any).id !== studentId) {
      return res.status(403).json({ message: "Доступ запрещен" });
    }
    
    const stats = await storage.getStudentStats(studentId);
    return res.json(stats);
  });

  // Set up Telegram bot API
  const bot = new Telegraf(process.env.TELEGRAM_BOT_TOKEN || "dummy_token_for_development");
  console.log("Setting up Telegram bot with token:", process.env.TELEGRAM_BOT_TOKEN ? "Real token provided" : "Using dummy token");
  configureBot(bot, storage);
  
  // Функция генерации кода подтверждения
  const generateVerificationCode = (): string => {
    // Формат кода: буквы и цифры, разделенные подчеркиваниями для лучшей читаемости
    const part1 = nanoid(4).toUpperCase();
    const part2 = nanoid(2).toUpperCase();
    const part3 = nanoid(5).toUpperCase();
    return `${part1}_${part2}-${part3}`;
  };

  // Функция проверки срока действия кода
  const isCodeExpired = (expires: Date): boolean => {
    return new Date() > expires;
  };

  // Telegram connection API
  app.post("/api/telegram/link", async (req, res) => {
    try {
      const data = telegramLinkSchema.parse(req.body);
      const user = await storage.getUserByUsername(data.username);

      if (!user || user.password !== data.password) {
        return res.status(401).json({ message: "Неверный логин или пароль" });
      }

      // Update user with Telegram ID
      const updatedUser = await storage.updateUser(user.id, {
        telegramId: data.telegramId,
        telegramUsername: data.telegramUsername,
        telegramConnected: true
      });

      if (!updatedUser) {
        return res.status(500).json({ message: "Не удалось обновить пользователя" });
      }

      // Create notification about successful connection
      await storage.createNotification({
        userId: user.id,
        title: "Telegram подключен",
        message: "Ваш аккаунт был успешно привязан к Telegram",
        type: "system",
        relatedId: null
      });

      return res.status(200).json({ success: true, message: "Аккаунт успешно привязан к Telegram" });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Некорректные данные", errors: error.errors });
      }
      return res.status(500).json({ message: "Внутренняя ошибка сервера" });
    }
  });

  // Привязка Telegram с помощью кода подтверждения (без авторизации)
  app.post("/api/telegram/code/link", async (req, res) => {
    try {
      const data = telegramCodeLinkSchema.parse(req.body);
      
      let foundUserId: number | null = null;
      
      // Ищем пользователя по коду подтверждения
      // Используем Array.from для обхода Map для совместимости со старыми версиями JS
      Array.from(telegramVerificationCodes.entries()).forEach(([userId, codeData]) => {
        if (codeData.code === data.code) {
          // Проверяем срок действия кода
          if (isCodeExpired(codeData.expires)) {
            telegramVerificationCodes.delete(userId); // Удаляем просроченный код
            if (foundUserId === null) {
              foundUserId = -1; // Маркер для просроченного кода
            }
          } else {
            foundUserId = userId;
          }
        }
      });
      
      if (foundUserId === -1) {
        return res.status(400).json({ message: "Срок действия кода истек" });
      }
      
      if (foundUserId === null) {
        return res.status(400).json({ message: "Неверный код подтверждения" });
      }
      
      // Получаем пользователя
      const user = await storage.getUser(foundUserId);
      if (!user) {
        return res.status(404).json({ message: "Пользователь не найден" });
      }
      
      // Обновляем пользователя с данными из Telegram
      const updatedUser = await storage.updateUser(user.id, {
        telegramId: data.telegramId,
        telegramUsername: data.telegramUsername,
        telegramConnected: true
      });
      
      if (!updatedUser) {
        return res.status(500).json({ message: "Не удалось обновить пользователя" });
      }
      
      // Удаляем использованный код
      telegramVerificationCodes.delete(foundUserId);
      
      // Создаем уведомление об успешном подключении
      await storage.createNotification({
        userId: user.id,
        title: "Telegram подключен",
        message: "Ваш аккаунт был успешно привязан к Telegram",
        type: "system",
        relatedId: null
      });
      
      return res.status(200).json({ 
        success: true, 
        message: "Аккаунт успешно привязан к Telegram",
        username: user.username,
        firstName: user.firstName,
        lastName: user.lastName,
        role: user.role
      });
      
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Некорректные данные", errors: error.errors });
      }
      return res.status(500).json({ message: "Внутренняя ошибка сервера" });
    }
  });

  // Генерация кода для подключения Telegram
  app.post("/api/telegram/code/generate", isAuthenticated, async (req, res) => {
    const userId = (req.user as any).id;
    const user = await storage.getUser(userId);
    
    if (!user) {
      return res.status(404).json({ message: "Пользователь не найден" });
    }
    
    // Генерируем новый код подтверждения
    const code = generateVerificationCode();
    
    // Устанавливаем срок действия кода (10 минут)
    const expires = new Date();
    expires.setMinutes(expires.getMinutes() + 10);
    
    // Сохраняем код в Map
    telegramVerificationCodes.set(userId, { code, expires });
    
    return res.status(200).json({ 
      code,
      expiresIn: "10 минут" 
    });
  });
  
  // Проверка статуса подключения к Telegram
  app.get("/api/telegram/status", isAuthenticated, async (req, res) => {
    const userId = (req.user as any).id;
    const user = await storage.getUser(userId);
    
    if (!user) {
      return res.status(404).json({ message: "Пользователь не найден" });
    }
    
    return res.json({ 
      connected: user.telegramConnected, 
      username: user.telegramUsername 
    });
  });

  // Отвязка Telegram
  app.post("/api/telegram/unlink", isAuthenticated, async (req, res) => {
    const userId = (req.user as any).id;
    const user = await storage.getUser(userId);
    
    if (!user) {
      return res.status(404).json({ message: "Пользователь не найден" });
    }
    
    const updatedUser = await storage.updateUser(userId, {
      telegramId: null,
      telegramUsername: null,
      telegramConnected: false
    });

    if (!updatedUser) {
      return res.status(500).json({ message: "Не удалось отвязать Telegram" });
    }

    // Create notification about unlinking
    await storage.createNotification({
      userId: user.id,
      title: "Telegram отключен",
      message: "Ваш аккаунт был отвязан от Telegram",
      type: "system",
      relatedId: null
    });

    return res.status(200).json({ success: true, message: "Telegram успешно отвязан" });
  });

  return httpServer;
}
