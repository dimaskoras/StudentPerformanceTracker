import { User, InsertUser, Course, InsertCourse, Grade, InsertGrade, Notification, InsertNotification, 
         users, courses, grades, notifications } from "@shared/schema";
import { db } from "./db";
import { eq, and, desc, sql, SQL } from "drizzle-orm";
import { IStorage } from "./storage";
import connectPg from "connect-pg-simple";
import session from "express-session";
import { pool } from "./db";

const PostgresSessionStore = connectPg(session);

export interface UserWithStats extends User {
  gradesCount?: number;
  averageGrade?: number;
  absencesCount?: number;
  telegramConnected: boolean;
}

export class DatabaseStorage implements IStorage {
  sessionStore: session.Store;

  constructor() {
    this.sessionStore = new PostgresSessionStore({
      pool,
      createTableIfMissing: true,
      tableName: 'session'
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    try {
      const [user] = await db.select().from(users).where(eq(users.id, id));
      return user;
    } catch (error) {
      console.error("Error in getUser:", error);
      return undefined;
    }
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    try {
      const [user] = await db.select().from(users).where(eq(users.username, username));
      return user;
    } catch (error) {
      console.error("Error in getUserByUsername:", error);
      return undefined;
    }
  }

  async createUser(user: InsertUser): Promise<User> {
    try {
      const [insertedUser] = await db.insert(users).values(user).returning();
      return insertedUser;
    } catch (error) {
      console.error("Error in createUser:", error);
      throw error;
    }
  }

  async updateUser(id: number, data: Partial<User>): Promise<User | undefined> {
    try {
      const [updatedUser] = await db.update(users)
        .set(data)
        .where(eq(users.id, id))
        .returning();
      return updatedUser;
    } catch (error) {
      console.error("Error in updateUser:", error);
      return undefined;
    }
  }

  async deleteUser(id: number): Promise<boolean> {
    try {
      // Сначала удаляем все связанные записи
      await db.delete(notifications).where(eq(notifications.userId, id));
      await db.delete(grades).where(eq(grades.studentId, id));
      await db.delete(courses).where(eq(courses.teacherId, id));
      
      // Затем удаляем пользователя
      const result = await db.delete(users).where(eq(users.id, id));
      return true;
    } catch (error) {
      console.error("Error in deleteUser:", error);
      return false;
    }
  }

  async getUsers(role?: string): Promise<User[]> {
    try {
      if (role) {
        return await db.select().from(users).where(eq(users.role, role));
      }
      return await db.select().from(users);
    } catch (error) {
      console.error("Error in getUsers:", error);
      return [];
    }
  }

  async getCourse(id: number): Promise<Course | undefined> {
    try {
      const [course] = await db.select().from(courses).where(eq(courses.id, id));
      return course;
    } catch (error) {
      console.error("Error in getCourse:", error);
      return undefined;
    }
  }

  async createCourse(course: InsertCourse): Promise<Course> {
    try {
      const [insertedCourse] = await db.insert(courses).values(course).returning();
      return insertedCourse;
    } catch (error) {
      console.error("Error in createCourse:", error);
      throw error;
    }
  }

  async updateCourse(id: number, data: Partial<Course>): Promise<Course | undefined> {
    try {
      const [updatedCourse] = await db.update(courses)
        .set(data)
        .where(eq(courses.id, id))
        .returning();
      return updatedCourse;
    } catch (error) {
      console.error("Error in updateCourse:", error);
      return undefined;
    }
  }

  async deleteCourse(id: number): Promise<boolean> {
    try {
      // Сначала удаляем все связанные оценки
      await db.delete(grades).where(eq(grades.courseId, id));
      
      // Затем удаляем курс
      await db.delete(courses).where(eq(courses.id, id));
      return true;
    } catch (error) {
      console.error("Error in deleteCourse:", error);
      return false;
    }
  }

  async getCoursesByTeacher(teacherId: number): Promise<Course[]> {
    try {
      return await db.select().from(courses).where(eq(courses.teacherId, teacherId));
    } catch (error) {
      console.error("Error in getCoursesByTeacher:", error);
      return [];
    }
  }

  async getAllCourses(): Promise<Course[]> {
    try {
      return await db.select().from(courses);
    } catch (error) {
      console.error("Error in getAllCourses:", error);
      return [];
    }
  }

  async getGrade(id: number): Promise<Grade | undefined> {
    try {
      const [grade] = await db.select().from(grades).where(eq(grades.id, id));
      return grade;
    } catch (error) {
      console.error("Error in getGrade:", error);
      return undefined;
    }
  }

  async createGrade(grade: InsertGrade): Promise<Grade> {
    try {
      console.log("Creating grade with data:", JSON.stringify(grade, null, 2));
      
      // Проверяем и преобразуем дату, если она передана в виде объекта Date или строки
      const gradeWithProperDate = {
        ...grade,
        // Если date существует и не является строкой, преобразуем его в ISO строку
        date: grade.date instanceof Date ? 
                grade.date : 
                (typeof grade.date === 'string' && grade.date ? 
                  new Date(grade.date) : 
                  new Date())
      };
      
      console.log("Processed grade data:", JSON.stringify(gradeWithProperDate, null, 2));
      
      const [insertedGrade] = await db.insert(grades).values(gradeWithProperDate).returning();
      
      // Если у студента есть привязанный Telegram, отправляем уведомление
      const student = await this.getUser(grade.studentId);
      if (student && student.telegramConnected && student.telegramId) {
        // Получаем информацию о курсе для уведомления
        const course = await this.getCourse(grade.courseId);
        
        // Создаем уведомление в базе данных
        await this.createNotification({
          userId: grade.studentId,
          title: `Новая оценка по предмету ${course?.name || 'Неизвестный предмет'}`,
          message: `Вы получили оценку ${grade.value}${grade.comment ? `. Комментарий: ${grade.comment}` : ''}`,
          type: 'grade',
          relatedId: insertedGrade.id
        });
      }
      
      return insertedGrade;
    } catch (error) {
      console.error("Error in createGrade:", error);
      throw error;
    }
  }

  async getGradesByStudent(studentId: number): Promise<Grade[]> {
    try {
      return await db.select()
        .from(grades)
        .where(eq(grades.studentId, studentId))
        .orderBy(desc(grades.date));
    } catch (error) {
      console.error("Error in getGradesByStudent:", error);
      return [];
    }
  }

  async getGradesByCourse(courseId: number): Promise<Grade[]> {
    try {
      return await db.select()
        .from(grades)
        .where(eq(grades.courseId, courseId))
        .orderBy(desc(grades.date));
    } catch (error) {
      console.error("Error in getGradesByCourse:", error);
      return [];
    }
  }

  async getGradesByStudentAndCourse(studentId: number, courseId: number): Promise<Grade[]> {
    try {
      return await db.select()
        .from(grades)
        .where(and(
          eq(grades.studentId, studentId),
          eq(grades.courseId, courseId)
        ))
        .orderBy(desc(grades.date));
    } catch (error) {
      console.error("Error in getGradesByStudentAndCourse:", error);
      return [];
    }
  }

  async getRecentGradesByStudent(studentId: number, limit: number = 5): Promise<Grade[]> {
    try {
      return await db.select()
        .from(grades)
        .where(eq(grades.studentId, studentId))
        .orderBy(desc(grades.date))
        .limit(limit);
    } catch (error) {
      console.error("Error in getRecentGradesByStudent:", error);
      return [];
    }
  }

  async updateGradeRead(id: number, isRead: boolean): Promise<Grade | undefined> {
    try {
      const [updatedGrade] = await db.update(grades)
        .set({ isRead })
        .where(eq(grades.id, id))
        .returning();
      return updatedGrade;
    } catch (error) {
      console.error("Error in updateGradeRead:", error);
      return undefined;
    }
  }

  async getNotification(id: number): Promise<Notification | undefined> {
    try {
      const [notification] = await db.select().from(notifications).where(eq(notifications.id, id));
      return notification;
    } catch (error) {
      console.error("Error in getNotification:", error);
      return undefined;
    }
  }

  async createNotification(notification: InsertNotification): Promise<Notification> {
    try {
      const [insertedNotification] = await db.insert(notifications).values(notification).returning();
      return insertedNotification;
    } catch (error) {
      console.error("Error in createNotification:", error);
      throw error;
    }
  }

  async getNotificationsByUser(userId: number): Promise<Notification[]> {
    try {
      return await db.select()
        .from(notifications)
        .where(eq(notifications.userId, userId))
        .orderBy(desc(notifications.date));
    } catch (error) {
      console.error("Error in getNotificationsByUser:", error);
      return [];
    }
  }

  async getUnreadNotificationsByUser(userId: number): Promise<Notification[]> {
    try {
      return await db.select()
        .from(notifications)
        .where(and(
          eq(notifications.userId, userId),
          eq(notifications.isRead, false)
        ))
        .orderBy(desc(notifications.date));
    } catch (error) {
      console.error("Error in getUnreadNotificationsByUser:", error);
      return [];
    }
  }

  async updateNotificationRead(id: number, isRead: boolean): Promise<Notification | undefined> {
    try {
      const [updatedNotification] = await db.update(notifications)
        .set({ isRead })
        .where(eq(notifications.id, id))
        .returning();
      return updatedNotification;
    } catch (error) {
      console.error("Error in updateNotificationRead:", error);
      return undefined;
    }
  }

  async getStudentsWithStats(): Promise<UserWithStats[]> {
    try {
      // Получаем всех студентов
      const students = await this.getUsers("student");
  
      // Для каждого студента получаем статистику
      const studentsWithStats = await Promise.all(students.map(async (student) => {
        const stats = await this.getStudentStats(student.id);
        
        return {
          ...student,
          gradesCount: stats.newGradesCount,
          averageGrade: stats.averageGrade,
          absencesCount: 0, // Пока не реализовано
          telegramConnected: !!student.telegramConnected
        };
      }));
  
      return studentsWithStats;
    } catch (error) {
      console.error("Error in getStudentsWithStats:", error);
      return [];
    }
  }

  async getStudentStats(studentId: number): Promise<{
    averageGrade: number;
    uncompletedCourses: number;
    newGradesCount: number;
    attendancePercentage: number;
  }> {
    try {
      // Получаем все оценки студента
      const studentGrades = await this.getGradesByStudent(studentId);
  
      // Считаем среднюю оценку
      const totalGradeValue = studentGrades.reduce((sum, grade) => sum + grade.value, 0);
      const averageGrade = studentGrades.length > 0 ? totalGradeValue / studentGrades.length : 0;
  
      // Считаем количество новых (непрочитанных) оценок
      const newGradesCount = studentGrades.filter(grade => !grade.isRead).length;
  
      // Пока возвращаем заглушки для остальных показателей
      return {
        averageGrade,
        uncompletedCourses: 0,
        newGradesCount,
        attendancePercentage: 100
      };
    } catch (error) {
      console.error("Error in getStudentStats:", error);
      return {
        averageGrade: 0,
        uncompletedCourses: 0,
        newGradesCount: 0,
        attendancePercentage: 0
      };
    }
  }

  async initializeData(): Promise<void> {
    try {
      console.log("Проверка наличия тестовых данных...");
      
      // Проверяем существование пользователей
      const existingUsers = await this.getUsers();
      
      if (existingUsers.length === 0) {
        console.log("Инициализация тестовых данных...");
        
        // Создаем тестовых пользователей
        const teacher = await this.createUser({
          username: "teacher1",
          password: "password",
          firstName: "Иван",
          lastName: "Иванов",
          email: "teacher1@example.com",
          role: "teacher"
        });
        
        const student1 = await this.createUser({
          username: "student1",
          password: "password",
          firstName: "Петр",
          lastName: "Петров",
          email: "student1@example.com",
          role: "student"
        });
        
        const student2 = await this.createUser({
          username: "student2",
          password: "password",
          firstName: "Мария",
          lastName: "Сидорова",
          email: "student2@example.com",
          role: "student"
        });
        
        // Создаем тестовые курсы
        const course1 = await this.createCourse({
          name: "Математика",
          description: "Высшая математика для студентов 1 курса",
          teacherId: teacher.id
        });
        
        const course2 = await this.createCourse({
          name: "Информатика",
          description: "Основы программирования на Python",
          teacherId: teacher.id
        });
        
        const course3 = await this.createCourse({
          name: "Физика",
          description: "Механика и оптика",
          teacherId: teacher.id
        });
        
        // Создаем тестовые оценки
        await this.createGrade({
          studentId: student1.id,
          courseId: course1.id,
          value: 4,
          date: new Date(),
          workType: "Контрольная работа №1",
          comment: "Хорошая работа, но есть ошибки в 3-м задании"
        });
        
        await this.createGrade({
          studentId: student1.id,
          courseId: course2.id,
          value: 5,
          date: new Date(),
          workType: "Лабораторная работа №2",
          comment: "Отличная работа!"
        });
        
        await this.createGrade({
          studentId: student2.id,
          courseId: course1.id,
          value: 3,
          date: new Date(),
          workType: "Контрольная работа №1",
          comment: "Нужно больше практики"
        });
        
        console.log("Тестовые данные успешно созданы");
      } else {
        console.log("Тестовые данные уже существуют");
      }
    } catch (error) {
      console.error("Ошибка при инициализации данных:", error);
      throw error;
    }
  }
}